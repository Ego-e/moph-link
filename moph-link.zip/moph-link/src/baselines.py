"""P2 位置基线：只用胞体侧信息预测轴突大区分布。

泄漏纪律：输入只允许 soma_x/y/z、SomaLayer、SomaLocation；
IT/PT/CT（AxonProjectionType）和 Subtype 是标签泄漏，禁止进任何特征。

基线（层层加码，B2−B0 的差 = 纯位置的信息含量，是 P3 的靶子）：
  B0  常数基线   预测训练集平均分布（什么都不懂的参照系）
  B1  区先验查表 训练集里"胞体在脑区R"的平均分布，没见过的区回退B0
  B2a 坐标回归   特征=soma_xyz，ridge 和 kNN 两版
  B2b 坐标+层    特征=soma_xyz+层独热，同两版模型

评估：主指标 1−余弦；JS散度（稳健性检查）；top-5 命中数（直观辅助）。
划分：GroupKFold 5 折按 sample_id 分组（同一样本的神经元相关，必须整组切）。
B1/B2b 只在官方标签齐全的 82 神经元子集上跑；B0/B2a 在 100 和 82 上各跑一次。
"""

from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.model_selection import GroupKFold
from sklearn.neighbors import NearestNeighbors
from scipy.spatial.distance import jensenshannon

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "inputs" / "data" / "raw"
OUT = ROOT / "outputs"
FIG = OUT / "figures"
FIG.mkdir(parents=True, exist_ok=True)

K_GRID = [3, 5, 7, 11, 15, 21]   # kNN 的候选 k，折内留一验证挑
LAYERS = ["L1", "L2/3", "L4", "L5", "L6a", "L6b"]
N_FOLDS, SEED = 5, 42


# ---------- 指标（三把尺子，全程钉死不换） ----------
def cosine_dist(p, q):
    """1−余弦相似度：只比分布形状，0=完全同形。"""
    return 1.0 - float(np.dot(p, q) / (np.linalg.norm(p) * np.linalg.norm(q) + 1e-12))

def js_dist(p, q):
    """JS散度的平方根（base 2，0~1）：分布比较的正统尺，稳健性检查用。"""
    return float(jensenshannon(p, q, base=2))

def top5_hit(p, q):
    """预测占比前5的区与真实前5的区重合数（0~5）。"""
    a = set(np.argsort(-p)[:5]); b = set(np.argsort(-q)[:5])
    return len(a & b)


# ---------- 模型 ----------
def predict_b0(train_Y):
    """B0：训练集逐区平均占比。fit 返回一个 45 维向量，predict 恒等输出。"""
    return train_Y.mean(axis=0)

def predict_b1(train_meta, train_Y, loc_test):
    """B1：查表。loc→训练集该区平均分布；没见过的区回退 B0。"""
    b0 = predict_b0(train_Y)
    table = {}
    for loc in np.unique(train_meta["SomaLocation"]):
        m = train_meta["SomaLocation"] == loc
        table[loc] = train_Y[m].mean(axis=0)
    return np.array([table.get(l, b0) for l in loc_test])

def ridge_fit_predict(F_tr, Y_tr, F_te, lam=10.0):
    """ridge：闭式解 (FᵀF+λI)⁻¹FᵀY，逐目标回归；预测clip非负再行归一化。"""
    F1_tr = np.hstack([F_tr, np.ones((len(F_tr), 1))])   # 加截距列
    F1_te = np.hstack([F_te, np.ones((len(F_te), 1))])
    A = F1_tr.T @ F1_tr + lam * np.eye(F1_tr.shape[1])
    W = np.linalg.solve(A, F1_tr.T @ Y_tr)               # (d+1, 45)
    P = F1_te @ W
    P = np.clip(P, 0, None)
    s = P.sum(axis=1, keepdims=True)
    return np.where(s > 0, P / np.maximum(s, 1e-12), 1.0 / P.shape[1])

def knn_fit_predict(F_tr, Y_tr, F_te, k):
    """kNN：取训练集最近 k 个邻居的分布平均。k 由折内留一验证挑。"""
    nn = NearestNeighbors(n_neighbors=k).fit(F_tr)
    _, idx = nn.kneighbors(F_te)
    return Y_tr[idx].mean(axis=1)

def pick_k(F, Y):
    """折内留一验证：轮流留1个当测试，选平均余弦距离最小的 k。"""
    nn_all = NearestNeighbors(n_neighbors=len(F)).fit(F)
    _, idx_all = nn_all.kneighbors(F)          # 每行：按距离排序的全体邻居索引
    best_k, best_err = None, np.inf
    for k in K_GRID:
        errs = []
        for i in range(len(F)):
            nb = [j for j in idx_all[i] if j != i][:k]   # 排除自己
            errs.append(cosine_dist(Y[nb].mean(axis=0), Y[i]))
        e = float(np.mean(errs))
        if e < best_err:
            best_err, best_k = e, k
    return best_k


def run_cohort(name, X, Y, meta):
    """在给定子集上跑全部可行基线，返回逐神经元成绩表。

    X: 特征 DataFrame（soma_x/y/z 可选 SomaLocation/SomaLayer 列）
    Y: 行归一化的分布矩阵 (n, 45)
    meta: 含 SomaLocation 的表（X 是它的子集视图）
    """
    has_label = "SomaLocation" in X.columns
    groups = X["sample_id"].values
    gkf = GroupKFold(n_splits=N_FOLDS)
    rows = []
    for tr, te in gkf.split(X, groups=groups):
        Y_tr = Y[tr]
        # ---- B0 ----
        b0 = predict_b0(Y_tr)
        # ---- B2a：纯 xyz ----
        F_tr = X.iloc[tr][["soma_x", "soma_y", "soma_z"]].values
        F_te = X.iloc[te][["soma_x", "soma_y", "soma_z"]].values
        rg = ridge_fit_predict(F_tr, Y_tr, F_te)
        k = pick_k(F_tr, Y_tr)
        knn = knn_fit_predict(F_tr, Y_tr, F_te, k)
        preds = {"B2a-ridge": rg, "B2a-kNN": knn}
        kcols = {"B2a-kNN": k}
        if has_label:
            # ---- B1：区先验查表 ----
            loc_tr = X.iloc[tr]["SomaLocation"].values
            loc_te = X.iloc[te]["SomaLocation"].values
            preds["B1-区先验"] = predict_b1(X.iloc[tr].assign(SomaLocation=loc_tr),
                                          Y_tr, loc_te)
            # ---- B2b：xyz + 层独热 ----
            lay = X["SomaLayer"].fillna("unknown")
            onehot = np.array([[1.0 if l == lay_i else 0.0 for l in LAYERS]
                               for lay_i in lay])
            Fb_tr = np.hstack([F_tr, onehot[tr]])
            Fb_te = np.hstack([F_te, onehot[te]])
            preds["B2b-ridge"] = ridge_fit_predict(Fb_tr, Y_tr, Fb_te)
            kb = pick_k(Fb_tr, Y_tr)
            preds["B2b-kNN"] = knn_fit_predict(Fb_tr, Y_tr, Fb_te, kb)
            kcols["B2b-kNN"] = kb
        # ---- 逐神经元记成绩（真实值永远在 Y 里，测试折只看 Y[te]）----
        for j, i in enumerate(te):
            rows.append({"cohort": name, "sample_id": int(X.iloc[i]["sample_id"]),
                         "neuron_id": int(X.iloc[i]["neuron_id"]),
                         "baseline": "B0-平均", "cos": cosine_dist(b0, Y[i]),
                         "js": js_dist(b0, Y[i]), "top5": top5_hit(b0, Y[i])})
            for bname, P in preds.items():
                rows.append({"cohort": name, "sample_id": int(X.iloc[i]["sample_id"]),
                             "neuron_id": int(X.iloc[i]["neuron_id"]),
                             "baseline": bname, "k": kcols.get(bname, np.nan),
                             "cos": cosine_dist(P[j], Y[i]),
                             "js": js_dist(P[j], Y[i]),
                             "top5": top5_hit(P[j], Y[i])})
    return pd.DataFrame(rows)


def main():
    soma = pd.read_csv(OUT / "labels_soma.csv")
    mat = pd.read_csv(OUT / "axons_big_matrix.csv")
    df = soma.merge(mat, on=["sample_id", "neuron_id"], how="inner")
    regions = [c for c in mat.columns if c not in ("sample_id", "neuron_id")]
    Y_all = df[regions].values.astype(float)
    Y_all = Y_all / Y_all.sum(axis=1, keepdims=True)          # 行归一化成占比
    print(f"合并后 {len(df)} 神经元 × {len(regions)} 个大区")

    # ---- Table S2 官方标签（82 神经元子集）----
    # Linux 文件名大小写敏感，统一转小写再匹配
    s2_path = next((p for p in RAW.glob("*.xlsx")
                    if "table" in p.name.lower() and "s2" in p.name.lower()), None)
    if s2_path is None:
        print("未找到 Table S2，B1/B2b 跳过，只跑 100 人版的 B0/B2a")
    else:
        s2 = pd.read_excel(s2_path)
        s2 = s2[s2["ProjectID"] == "ISO"]
        s2["nid3"] = s2["NeuronID"].astype(str)
        df = df.copy()
        df["sid"] = "S" + df["sample_id"].astype(str)
        df["nid3"] = df["neuron_id"].apply(lambda x: f"N{x:03d}")
        df = df.merge(s2[["SampleID", "nid3", "SomaLocation", "SomaLayer"]],
                      left_on=["sid", "nid3"], right_on=["SampleID", "nid3"],
                      how="left")
    lab = df[df["SomaLocation"].notna()].copy() if "SomaLocation" in df.columns \
        else df.iloc[0:0]
    if len(lab):
        print(f"官方标签齐全 {len(lab)}/{len(df)}，子集来自 {lab['sample_id'].nunique()} 个样本")
    else:
        print("无官方标签，只跑 B0/B2a")

    X100 = df[["sample_id", "neuron_id", "soma_x", "soma_y", "soma_z"]]
    cohorts = [run_cohort("all100", X100, Y_all, df)]
    if len(lab):   # 只在官方标签齐全时才有 B1/B2b
        X82 = lab[["sample_id", "neuron_id", "soma_x", "soma_y", "soma_z",
                   "SomaLocation", "SomaLayer"]]
        cohorts.append(run_cohort(
            "labeled82", X82.reset_index(drop=True),
            Y_all[df["SomaLocation"].notna()], lab))
    res = pd.concat(cohorts, ignore_index=True)

    res.to_csv(OUT / "baseline_report.csv", index=False)
    summ = (res.groupby(["cohort", "baseline"])[["cos", "js", "top5"]]
            .agg(["mean", "std"]).round(4))
    summ.to_csv(OUT / "baseline_summary.csv")
    print(summ.to_string())

    # ---- 箱线图：主指标余弦距离，按 cohort 分面板（图内用英文避免字体缺字）----
    order100 = ["B0-平均", "B2a-kNN", "B2a-ridge"]
    order82 = ["B0-平均", "B1-区先验", "B2a-kNN", "B2a-ridge",
               "B2b-kNN", "B2b-ridge"]
    en = {"B0-平均": "B0 mean", "B1-区先验": "B1 region-prior",
          "B2a-kNN": "B2a kNN", "B2a-ridge": "B2a ridge",
          "B2b-kNN": "B2b kNN", "B2b-ridge": "B2b ridge"}
    panels = [("all100", order100)]
    if len(lab):
        panels.append(("labeled82", order82))
    fig, axes = plt.subplots(1, len(panels), figsize=(6 * len(panels), 5),
                             sharey=True)
    if len(panels) == 1:
        axes = [axes]
    for ax, (name, order) in zip(axes, panels):
        sub = res[res["cohort"] == name]
        cols = [b for b in order if sub["baseline"].str.startswith(b).any()]
        data = [sub[sub["baseline"].str.startswith(b)]["cos"] for b in cols]
        ax.boxplot(data, labels=[en[b].replace(" ", "\n", 1) for b in cols])
        ax.set_title(name)
        ax.set_ylabel("1 - cosine" if name == panels[0][0] else "")
        ax.tick_params(axis="x", labelsize=8)
    fig.suptitle("Soma-only baselines for axon projection distribution (lower = better)")
    fig.tight_layout()
    fig.savefig(FIG / "baseline_boxplot.png", dpi=150)
    print("图已存 outputs/figures/baseline_boxplot.png")


if __name__ == "__main__":
    main()
