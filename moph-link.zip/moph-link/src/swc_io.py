"""SWC 文件读取与解析（练手A第一版）

本批数据格式（已用 233795_135 样例核实）：
  # 开头是注释行；数据行 7 列：PointNo Type X Y Z Radius Parent
  Type 编码：1=胞体  2=轴突  3=树突（无 4，树突不分 apical/basal）
  半径列全是占位值 1（降采样产物），任何形态判断都不用它
"""
from io import StringIO
from dataclasses import dataclass
from pathlib import Path
import numpy as np

COLUMN_NAMES = ["point_no", "type", "x", "y", "z", "radius", "parent"]
TYPE_SOMA, TYPE_AXON, TYPE_DEND = 1, 2, 3

# 项目根：本文件在 src/ 下，往上一级。根目录整体搬家代码不用改。
ROOT = Path(__file__).resolve().parent.parent
RAW_DIR = ROOT / "inputs" / "data" / "raw"


def resolve_swc(path_str):
    """manifest里存的路径 → 现在真实存在的路径。

    兼容两种存法：
      绝对路径（旧manifest，数据搬过家）→ 自动换算到 inputs/data/raw/ 下重试
      相对路径（新manifest，按项目根存）→ 按 ROOT 拼接
    都找不到就明确报错，绝不悄悄跳过。
    """
    p = Path(path_str)
    if p.is_absolute():
        if p.exists():
            return p
        if "data/raw/" in path_str:
            cand = RAW_DIR / path_str.split("data/raw/", 1)[1]
            if cand.exists():
                return cand
        raise FileNotFoundError(f"SWC 文件找不到：{path_str}")
    cand = ROOT / p
    if cand.exists():
        return cand
    raise FileNotFoundError(f"SWC 文件找不到：{path_str}（尝试过 {cand}）")


def parse_swc(path):
    """读一个 SWC 文件 → (points 二维数组, comments 注释列表)。

    返回的 points 形状是 (N, 7)，7 列对应 COLUMN_NAMES。
    坐标单位是 μm（全脑空间；是否 CCF 空间由 check_100 的图验证）。
    """
    comments, data_lines = [], []
    with open(path, "r", encoding="utf-8") as f:
        for ln in f:
            if ln.startswith("#"):
                comments.append(ln.rstrip("\n"))
            elif ln.strip():
                data_lines.append(ln)
    if not data_lines:
        raise ValueError(f"文件没有数据行: {path}")

    # StringIO：把字符串列表包装成"内存里的文件"，np.loadtxt 就能照常读
    points = np.loadtxt(StringIO("".join(data_lines)))
    if points.ndim == 1:          # 极端情况：全文件只有 1 个节点，手动补成二维
        points = points.reshape(1, -1)
    if points.shape[1] != 7:
        raise ValueError(f"列数不是 7: {path}，实际 {points.shape[1]} 列")
    return points, comments


@dataclass
class SwcNeuron:
    """一个神经元的重建数据。points: (N,7) 数组，source: 来自哪个文件。"""
    points: np.ndarray
    source: str = ""

    @property
    def types(self):
        return self.points[:, 1].astype(int)

    @property
    def xyz(self):
        return self.points[:, 2:5]

    def type_xyz(self, t):
        """取某一类型的所有节点坐标，如 type_xyz(2) 返回轴突全部坐标。"""
        return self.xyz[self.types == t]

    @property
    def soma_xyz(self):
        s = self.type_xyz(TYPE_SOMA)
        return s[0] if len(s) else None    # 没有胞体时返回 None，由体检去抓


def check_neuron(neuron):
    """单个神经元的基础体检。只检查、不修改，返回指标字典。

    降采样会把节点号抽稀，父节点可能"跳号"，但只要号码还在文件里
    就算连通；真正要抓的是父节点号整个缺失（断链）。
    """
    p = neuron.points
    types = neuron.types
    point_ids = set(p[:, 0].astype(int))
    parents = p[:, 6].astype(int)

    n_roots, n_bad_parent = 0, 0
    for pid in parents:
        if pid == -1:
            n_roots += 1          # 根节点（正常应有，胞体通常就是根）
        elif pid not in point_ids:
            n_bad_parent += 1     # 父节点不存在 = 断链，这条边接不上

    xyz_min = p[:, 2:5].min(axis=0)
    xyz_max = p[:, 2:5].max(axis=0)
    return {
        "source": neuron.source,
        "n_total": len(p),
        "n_soma": int((types == TYPE_SOMA).sum()),
        "n_axon": int((types == TYPE_AXON).sum()),
        "n_dend": int((types == TYPE_DEND).sum()),
        "n_roots": n_roots,
        "n_bad_parent": n_bad_parent,
        "xyz_min": xyz_min,
        "xyz_max": xyz_max,
    }
