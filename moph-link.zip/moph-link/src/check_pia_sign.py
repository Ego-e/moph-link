"""PIA_SIGN 符号确认：官方层级标签当标尺，测 pia 在 ±y 的哪一侧。

原理（标尺法，与 calibrate_space 用 S2 当标尺同款思路）：
  pia = −y  ⇔  同一解剖区内皮层越深 y 越大：L1 贴 pia → y 最小，
  L6b 最深 → y 最大。层级顺序是天然的方向标尺，
  AP 前后与左右半球两个悬案都用不上。

三路证据：
  主判据  逐区单调性：区内出现 ≥3 个不同层的区才收；区内各层平均 soma_y
          按深度序（L1→L6b）做 Spearman。rho>0 支持 pia=−y，rho<0 支持
          pia=+y。数两边的区数，多者胜。
  旁证    全池层深度序 vs 相对深度（soma_y 减去所在区均值，消区级曲率
          偏移）的 Spearman。rho>0 → pia=−y。
  旁证2   （可选，改 polarity_features.py 常量重跑，1 分钟）PIA_SIGN=−1
          与 +1 各跑一遍：皮层锥体细胞为主，正确符号下 has_apical 率应
          明显更高（apical 指向 pia）。

诚实边界：82 神经元分层后每层样本很少，主判据区数可能稀疏——稀疏或两边
接近时，暂按旁证定、polarity QC 挂"待全量定案"，全量 1.8 万上重跑定案。

怎么跑：python src/check_pia_sign.py
产出：outputs/pia_sign_verdict.txt
"""
import numpy as np
import pandas as pd
from scipy.stats import spearmanr

from baselines import OUT, LAYERS
from robustness import load_data

DEPTH = {name: i for i, name in enumerate(LAYERS)}   # L1=0 最浅 … L6b=5 最深


def main():
    df, Y = load_data()
    lab = df[df["SomaLayer"].notna() & df["SomaLocation"].notna()].copy()
    lab["depth"] = lab["SomaLayer"].map(DEPTH)
    lab = lab[lab["depth"].notna()]
    n = len(lab)

    # 主判据：逐区单调性
    rows = []
    for reg, g in lab.groupby("SomaLocation"):
        if g["depth"].nunique() < 3:
            continue
        m = g.groupby("depth")["soma_y"].mean()
        rho, _ = spearmanr(m.index, m.values)
        rows.append({"region": reg, "n_layers": int(g["depth"].nunique()),
                     "n_neurons": len(g), "rho": round(float(rho), 3),
                     "支持": "pia=−y" if rho > 0 else "pia=+y"})
    rt = pd.DataFrame(rows)
    n_pos = int((rt["rho"] > 0).sum())
    n_neg = int((rt["rho"] < 0).sum())

    # 旁证：全池相对深度（消区级偏移）
    lab["y_rel"] = lab["soma_y"] - lab.groupby("SomaLocation")["soma_y"].transform("mean")
    rho_all, p_all = spearmanr(lab["depth"], lab["y_rel"])

    win = "pia=−y（PIA_SIGN=−1）" if n_pos >= n_neg else "pia=+y（PIA_SIGN=+1）"
    sparse = len(rt) == 0 or abs(n_pos - n_neg) < max(1, len(rt) // 3)
    lines = [
        "PIA_SIGN 确认（check_pia_sign.py 生成）", "",
        f"可用神经元（有层标签+区标签+层可解析）：{n}",
        f"主判据（区内≥3层才收）：收 {len(rt)} 区，"
        f"支持 pia=−y：{n_pos} 区，支持 pia=+y：{n_neg} 区 → 多数证据指 {win}",
        f"旁证（全池相对深度 vs 层深度序）：rho={rho_all:+.3f}（p={p_all:.3f}）"
        f"→ {'支持 pia=−y' if rho_all > 0 else ('支持 pia=+y' if rho_all < 0 else '无信息')}",
        "",
        rt.to_string(index=False) if len(rt) else "（无区满足 ≥3 层，主判据缺席）",
        "",
        "结论：" + ("主判据可读，两路证据一致即定案。"
                    if not sparse else
                    "区数稀疏或两边接近——暂按旁证定符号，全量 1.8 万上重跑本脚本定案。"),
        "旁证2（可选）：PIA_SIGN=−1 与 +1 各跑一遍 polarity_features.py，",
        "  正确符号下 has_apical 率应明显更高（皮层锥体为主，apical 指 pia）。",
    ]
    (OUT / "pia_sign_verdict.txt").write_text("\n".join(lines), encoding="utf-8")
    print("已写 outputs/pia_sign_verdict.txt")


if __name__ == "__main__":
    main()
