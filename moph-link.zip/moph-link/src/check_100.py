"""对 manifest 里的 100 个神经元逐一解析、体检、画图。

产出：
  outputs/check_100_report.csv   逐神经元体检指标
  outputs/figures/soma_distribution.png        100 个胞体位置分布（坐标验证）
  outputs/figures/neuron_example_<S>_<N>.png   单神经元线稿（解析验证）
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")               # SSH 场景不弹窗，图存成文件
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection

import swc_io
from swc_io import SwcNeuron, check_neuron, resolve_swc

# 本文件在 src/ 下，往上一级 = 项目根；所有路径从根拼出来
ROOT = swc_io.ROOT
MANIFEST = ROOT / "outputs" / "subset_manifest.csv"
OUT_DIR = ROOT / "outputs"
FIG_DIR = OUT_DIR / "figures"


def draw_neuron(neuron, title, out_png):
    """单神经元线稿：每条边从节点连到父节点，XY 平面投影。
    红=轴突，蓝=树突，黑点=胞体。降采样后点稀疏，线稿足够看清结构。"""
    p = neuron.points
    id2idx = {int(p[i, 0]): i for i in range(len(p))}
    types = neuron.types

    seg_axon, seg_dend = [], []
    for i in range(len(p)):
        par = int(p[i, 6])
        if par == -1 or par not in id2idx:
            continue                   # 根或断链边不画，断链已由体检统计
        j = id2idx[par]
        seg = [neuron.xyz[i, :2], neuron.xyz[j, :2]]
        if types[i] == 2:
            seg_axon.append(seg)
        elif types[i] == 3:
            seg_dend.append(seg)

    fig, ax = plt.subplots(figsize=(8, 8))
    ax.add_collection(LineCollection(seg_axon, colors="tab:red", linewidths=0.5))
    ax.add_collection(LineCollection(seg_dend, colors="tab:blue", linewidths=0.5))
    soma = neuron.soma_xyz
    if soma is not None:
        ax.plot(soma[0], soma[1], "ko", ms=4)
    ax.set_title(title)
    ax.set_xlabel("X (μm)"); ax.set_ylabel("Y (μm)")
    ax.autoscale(); ax.set_aspect("equal")
    fig.savefig(out_png, dpi=150, bbox_inches="tight")
    plt.close(fig)


def main():
    os.makedirs(FIG_DIR, exist_ok=True)
    manifest = pd.read_csv(MANIFEST)

    records, xyz_all = [], []
    for _, row in manifest.iterrows():
        points, _ = swc_io.parse_swc(resolve_swc(row["full_path"]))
        neuron = SwcNeuron(points, source=row["full_path"])
        rec = check_neuron(neuron)
        rec["sample_id"] = row["sample_id"]
        rec["neuron_id"] = row["neuron_id"]
        for k in ("xyz_min", "xyz_max"):
            rec.pop(k)             # 单神经元的范围太细，汇总层面再看
        records.append(rec)
        xyz_all.append(neuron.soma_xyz)

    df = pd.DataFrame(records)
    df.to_csv(os.path.join(OUT_DIR, "check_100_report.csv"), index=False)

    # ---- 汇总摘要（直接决定数据能不能往下用）----
    print("\n===== 体检摘要 =====")
    print(f"解析成功：{len(df)}/{len(manifest)}")
    print(f"节点数 n_total：min={df.n_total.min()}  中位={int(df.n_total.median())}  max={df.n_total.max()}")
    print(f"缺胞体的神经元数：{(df.n_soma == 0).sum()}")
    print(f"多胞体的神经元数：{(df.n_soma > 1).sum()}")
    print(f"有断链的神经元数：{(df.n_bad_parent > 0).sum()}")
    print(f"断链边总数：{df.n_bad_parent.sum()}")

    # ---- 胞体分布图：坐标空间验证 ----
    xyz_all = [s for s in xyz_all if s is not None]
    xyz_arr = np.array(xyz_all)
    print(f"\n胞体坐标范围（μm）：")
    print(f"  X: {xyz_arr[:, 0].min():.0f} ~ {xyz_arr[:, 0].max():.0f}")
    print(f"  Y: {xyz_arr[:, 1].min():.0f} ~ {xyz_arr[:, 1].max():.0f}")
    print(f"  Z: {xyz_arr[:, 2].min():.0f} ~ {xyz_arr[:, 2].max():.0f}")

    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    axes[0].scatter(xyz_arr[:, 0], xyz_arr[:, 1], s=8, alpha=0.6)
    axes[0].set_xlabel("X (μm)"); axes[0].set_ylabel("Y (μm)")
    axes[0].set_title("Soma distribution, XY plane")
    axes[0].set_aspect("equal")
    axes[1].scatter(xyz_arr[:, 0], xyz_arr[:, 2], s=8, alpha=0.6)
    axes[1].set_xlabel("X (μm)"); axes[1].set_ylabel("Z (μm)")
    axes[1].set_title("Soma distribution, XZ plane")
    axes[1].set_aspect("equal")
    fig.tight_layout()
    fig.savefig(os.path.join(FIG_DIR, "soma_distribution.png"), dpi=150)
    plt.close(fig)

    # ---- 单神经元线稿：取清单第一个 ----
    r0 = manifest.iloc[0]
    points, _ = swc_io.parse_swc(resolve_swc(r0["full_path"]))
    n0 = SwcNeuron(points, source=r0["full_path"])
    title = f"{r0['sample_id']}_{r0['neuron_id']}  red=axon blue=dend"
    draw_neuron(n0, title, os.path.join(FIG_DIR,
                f"neuron_example_{r0['sample_id']}_{r0['neuron_id']}.png"))
    print(f"\n示例线稿已保存；两张图都在 {FIG_DIR}/")


if __name__ == "__main__":
    main()
