"""P2 基线的两项加固：(A) 特征标准化复核"层无增量"；(B) 留一样本(LOSO)稳健版。

A 的问题：原版坐标是微米量级、层独热是 0/1，kNN 距离和 ridge 惩罚都被坐标
主导，"层无增量"的结论可能被尺度混杂掩盖。把坐标标准化（减均值除标准差，
两个统计量只从训练折算，测试折照搬——全量标准化本身是泄漏）后重跑，
看层独热是否出现增量。

B 的问题：baseline_summary 的 std 按神经元算，但同一样本的神经元共享注射
方案与批次，真正的自由度是 7 个样本。LOSO 每次留出 1 个完整样本当测试，
看 B2a 对 B0 的优势是否在 7 个样本上个个成立。

结论对照 baseline_report.csv 的原版数字。
"""

import numpy as np
import pandas as pd
from pathlib import Path

from baselines import (ROOT, OUT, RAW, LAYERS,
                       cosine_dist, js_dist, top5_hit,
                       predict_b0, predict_b1,
                       ridge_fit_predict, knn_fit_predict, pick_k)

N_FOLDS = 5  # A 部分沿用与原版相同的 5 折口径，方便配对比较


def z_fit(F):
    """训练折上算均值和标准差（sd=0 的列按 1 处理，避免除零）。"""
    mu = F.mean(axis=0)
    sd = F.std(axis=0)
    sd[sd == 0] = 1.0
    return mu, sd


def z_apply(F, mu, sd):
    return (F - mu) / sd


def load_data():
    """与 baselines.main 相同的加载与 S2 合并（代码重复换解耦，可接受）。"""
    soma = pd.read_csv(OUT / "labels_soma.csv")
    mat = pd.read_csv(OUT / "axons_big_matrix.csv")
    df = soma.merge(mat, on=["sample_id", "neuron_id"], how="inner")
    regions = [c for c in mat.columns if c not in ("sample_id", "neuron_id")]
    Y = df[regions].values.astype(float)
    Y = Y / Y.sum(axis=1, keepdims=True)
    s2_path = next((p for p in RAW.glob("*.xlsx")
                    if "table" in p.name.lower() and "s2" in p.name.lower()), None)
    df["sid"] = "S" + df["sample_id"].astype(str)
    df["nid3"] = df["neuron_id"].apply(lambda x: f"N{x:03d}")
    if s2_path is not None:
        s2 = pd.read_excel(s2_path)
        s2 = s2[s2["ProjectID"] == "ISO"]
        s2["nid3"] = s2["NeuronID"].astype(str)
        df = df.merge(s2[["SampleID", "nid3", "SomaLocation", "SomaLayer"]],
                      left_on=["sid", "nid3"], right_on=["SampleID", "nid3"],
                      how="left")
    return df, Y


def onehot_layer(lay):
    return np.array([[1.0 if l == li else 0.0 for li in LAYERS] for l in lay])


def eval_preds(P, Y_te):
    return [(cosine_dist(P[j], Y_te[j]), js_dist(P[j], Y_te[j]),
             top5_hit(P[j], Y_te[j])) for j in range(len(Y_te))]


# ---------- A：标准化后的 5 折复核 ----------
def part_a(df, Y):
    from sklearn.model_selection import GroupKFold
    if "SomaLocation" not in df.columns:
        print("== A 跳过：无 Table S2 =="); return
    lab = df[df["SomaLocation"].notna()].reset_index(drop=True)
    if len(lab) < 20:
        print("== A 跳过：官方标签神经元不足 =="); return
    Y_lab = Y[df["SomaLocation"].notna()]
    lay = lab["SomaLayer"].fillna("unknown")
    onehot = onehot_layer(lay)
    rows = []
    for tr, te in GroupKFold(n_splits=N_FOLDS).split(lab, groups=lab["sample_id"]):
        Y_tr = Y_lab[tr]
        mu, sd = z_fit(lab.iloc[tr][["soma_x", "soma_y", "soma_z"]].values)
        Z_tr = z_apply(lab.iloc[tr][["soma_x", "soma_y", "soma_z"]].values, mu, sd)
        Z_te = z_apply(lab.iloc[te][["soma_x", "soma_y", "soma_z"]].values, mu, sd)
        Zb_tr = np.hstack([Z_tr, onehot[tr]])
        Zb_te = np.hstack([Z_te, onehot[te]])
        preds = {
            "B2a-ridge-z": ridge_fit_predict(Z_tr, Y_tr, Z_te),
            "B2a-kNN-z": knn_fit_predict(Z_tr, Y_tr, Z_te, pick_k(Z_tr, Y_tr)),
            "B2b-ridge-z": ridge_fit_predict(Zb_tr, Y_tr, Zb_te),
            "B2b-kNN-z": knn_fit_predict(Zb_tr, Y_tr, Zb_te, pick_k(Zb_tr, Y_tr)),
        }
        for bname, P in preds.items():
            for i, (c, j_, t5) in enumerate(eval_preds(P, Y_lab[te])):
                rows.append({"baseline": bname, "sample_id": lab.iloc[te[i]]["sample_id"],
                             "cos": c, "js": j_, "top5": t5})
    res = pd.DataFrame(rows)
    res.to_csv(OUT / "standardized_report.csv", index=False)
    # A 汇总 + 原版对照合成一张表
    z_sum = (res.groupby("baseline")[["cos", "js", "top5"]]
             .agg(["mean", "std"]).round(4))
    z_sum.columns = [f"{m}_{s}" for m, s in z_sum.columns]
    z_sum["version"] = "标准化"
    old = pd.read_csv(OUT / "baseline_report.csv")
    old = old[old["cohort"] == "labeled82"]
    o_sum = (old.groupby("baseline")[["cos", "js", "top5"]]
             .agg(["mean", "std"]).round(4))
    o_sum.columns = [f"{m}_{s}" for m, s in o_sum.columns]
    o_sum["version"] = "原版"
    pd.concat([z_sum, o_sum]).sort_index().to_csv(OUT / "robustness_A_summary.csv")

    # A 的层增量结论
    m = res.groupby("baseline")["cos"].mean()
    d_ridge = m.get("B2b-ridge-z", np.nan) - m.get("B2a-ridge-z", np.nan)
    d_knn = m.get("B2b-kNN-z", np.nan) - m.get("B2a-kNN-z", np.nan)
    return {"d_ridge": float(d_ridge), "d_knn": float(d_knn)}


# ---------- B：留一样本（LOSO）稳健版 ----------
def part_b(df, Y):
    if "SomaLocation" not in df.columns:
        print("== B 跳过：无 Table S2 =="); return
    lab = df[df["SomaLocation"].notna()].reset_index(drop=True)
    if lab["sample_id"].nunique() < 2:
        print("== B 跳过：样本数不足 =="); return
    Y_lab = Y[df["SomaLocation"].notna()]
    rows = []
    for sid in sorted(lab["sample_id"].unique()):
        te = lab.index[lab["sample_id"] == sid].values
        tr = lab.index[lab["sample_id"] != sid].values
        Y_tr = Y_lab[tr]
        b0 = predict_b0(Y_tr)
        preds = {"B0-平均": np.tile(b0, (len(te), 1)),
                 "B1-区先验": predict_b1(lab.iloc[tr], Y_tr,
                                       lab.iloc[te]["SomaLocation"].values)}
        mu, sd = z_fit(lab.iloc[tr][["soma_x", "soma_y", "soma_z"]].values)
        Z_tr = z_apply(lab.iloc[tr][["soma_x", "soma_y", "soma_z"]].values, mu, sd)
        Z_te = z_apply(lab.iloc[te][["soma_x", "soma_y", "soma_z"]].values, mu, sd)
        preds["B2a-kNN-z"] = knn_fit_predict(Z_tr, Y_tr, Z_te, pick_k(Z_tr, Y_tr))
        preds["B2a-ridge-z"] = ridge_fit_predict(Z_tr, Y_tr, Z_te)
        for bname, P in preds.items():
            cos_list = [cosine_dist(P[j], Y_lab[te[j]]) for j in range(len(te))]
            rows.append({"holdout_sample": int(sid), "n_test": len(te),
                         "baseline": bname, "cos_mean": float(np.mean(cos_list))})
    res = pd.DataFrame(rows)
    res.to_csv(OUT / "loso_summary.csv", index=False)
    wide = res.pivot(index="holdout_sample", columns="baseline", values="cos_mean")
    wide["n_test"] = res[res["baseline"] == "B0-平均"].set_index("holdout_sample")["n_test"]
    wide["B2a-kNN−B0"] = (wide["B2a-kNN-z"] - wide["B0-平均"]).round(4)
    wide.round(4).to_csv(OUT / "robustness_B_loso.csv")
    win = int((wide["B2a-kNN−B0"] < 0).sum())
    worse = wide[wide["B2a-kNN−B0"] >= 0].index.tolist()
    return {"n_samples": len(wide), "win": win,
            "worse": [int(s) for s in worse]}


if __name__ == "__main__":
    df, Y = load_data()
    a = part_a(df, Y) or {}
    b = part_b(df, Y) or {}
    if not a or not b:
        print("已写入: 无（S2 缺失，两部分跳过）")
        raise SystemExit
    # 两部分的结论写进一个纯文本文件，报告素材直接抄
    lines = [
        "P2 加固结论（robustness.py 生成）",
        "",
        f"A 层独热增量（标准化后，余弦距离差，B2b−B2a，越小=层越有用）：",
        f"  ridge: {a['d_ridge']:+.4f}   kNN: {a['d_knn']:+.4f}",
        "  判读标准：|差|≤0.01 → 层无增量；明显为负 → 层有增量（坐标没吸收完）",
        "",
        f"B 留一样本稳健性（B2a-kNN-z 对 B0）：",
        f"  优于B0的样本数：{b['win']}/{b['n_samples']}",
        f"  B2a 不优的样本：{b['worse'] if b['worse'] else '无'}",
        "  判读标准：≥5/7 结论稳；≤4/7 结论降级讨论",
        "",
        "明细见 robustness_A_summary.csv / robustness_B_loso.csv",
    ]
    (OUT / "robustness_verdict.txt").write_text("\n".join(lines), encoding="utf-8")
    print(f"已写入 outputs/: robustness_A_summary.csv, robustness_B_loso.csv, "
          f"robustness_verdict.txt (另 standardized_report.csv / loso_summary.csv 逐神经元明细)")
