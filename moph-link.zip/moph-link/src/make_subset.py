"""扫描数据目录，挑 n 个三文件齐全的神经元，写 manifest csv。

三种文件名（已核实，后缀 swc/txt 都兼容）：
  axon_full_recon-<SampleID>_<NeuronID>.txt
  dend_full_recon-<SampleID>_<NeuronID>.txt
  full_recon-<SampleID>_<NeuronID>.txt

路径自适应版：数据目录固定为 <root>/inputs/data/raw/，递归扫描
（SWC 在 raw/ 下哪一层、哪个子文件夹都能找到）；manifest 里存
相对项目根的路径，根目录整体搬家不影响后续脚本。
"""
import re
from pathlib import Path
import pandas as pd

# 正则：三种文件名各截出 kind(axon/dend/full)、SampleID、NeuronID 三段
FILE_RE = re.compile(
    r"^(axon_full_recon|dend_full_recon|full_recon)-(\d+)_(\d+)\.(swc|txt)$"
)

# 本文件在 src/ 下，往上一级 = 项目根
ROOT = Path(__file__).resolve().parent.parent
RAW_DIR = ROOT / "inputs" / "data" / "raw"
OUT_CSV = ROOT / "outputs" / "subset_manifest.csv"


def scan_dataset(data_dir):
    """递归扫描目录 → {(sample_id, neuron_id): {kind: 路径}}。"""
    found = {}
    for fp in sorted(data_dir.rglob("*")):
        if not fp.is_file():
            continue
        m = FILE_RE.match(fp.name)
        if m is None:
            continue
        kind = m.group(1).split("_")[0]      # 'axon' / 'dend' / 'full'
        key = (int(m.group(2)), int(m.group(3)))
        found.setdefault(key, {})[kind] = fp
    return found


def make_subset(data_dir, out_csv, n=100):
    """筛选三种文件齐全的神经元，按编号排序取前 n 个，登记成表。"""
    found = scan_dataset(data_dir)
    complete = {k: v for k, v in found.items() if set(v) == {"axon", "dend", "full"}}

    print(f"{data_dir}")
    print(f"目录里共发现 {len(found)} 个神经元，其中三文件齐全 {len(complete)} 个")

    keys = sorted(complete)[:n]
    rows = []
    for (s, nid) in keys:
        v = complete[(s, nid)]
        rows.append({
            "sample_id": s, "neuron_id": nid,
            # 存相对项目根的路径：根目录搬家后 manifest 仍然有效
            "axon_path": str(v["axon"].relative_to(ROOT)),
            "dend_path": str(v["dend"].relative_to(ROOT)),
            "full_path": str(v["full"].relative_to(ROOT)),
        })
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(out_csv, index=False)
    print(f"已登记前 {len(rows)} 个 → {out_csv}")


if __name__ == "__main__":
    make_subset(RAW_DIR, OUT_CSV, n=100)
