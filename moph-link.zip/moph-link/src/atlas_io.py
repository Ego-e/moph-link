"""CCF 脑区图加载与坐标查询（练手A第二步·上）

需要的两个数据文件（都在 data/raw/）：
  annotation_25.nrrd        三维脑区编号图，(528, 320, 456) 体素，每格25μm
  ccf_structure_graph.json  脑区编号→名称/父区的层级表（Allen官网，见README）

核心事实：编号图里存的是叶子脑区的编号，0 = 图谱未标注（脑外等）；
层级表里每个编号带着父编号，一路向上就能走到"大区"。
"""
import json
import numpy as np
import nrrd

VOXEL_UM = 25.0     # annotation_25 的体素边长（μm）
OUTSIDE = 0         # 图谱未标注的编号


def load_annotation(path):
    """读脑区编号图 → (三维int数组, header)。"""
    vol, header = nrrd.read(path)
    return vol.astype(np.int32), header


def load_graph(path):
    """读脑区层级表 → 名称表、父区表、深度表、根id。

    层级表是一个"族谱"：每个脑区带 parent_structure_id。
    根节点=深度0，往下逐层+1；isocortex 在现版本体里编号是 315（按缩写
    查，不要硬编码——旧版本体里 993 是 isocortex，新版 993 是 MOs）。
    """
    with open(path, "r", encoding="utf-8") as f:
        g = json.load(f)
    items = g["msg"] if isinstance(g, dict) and "msg" in g else g
    id2name, id2parent, id2acr = {}, {}, {}
    for it in items:
        i = int(it["id"])
        id2name[i] = it["name"]
        id2acr[i] = it.get("acronym", str(i))
        p = it.get("parent_structure_id")
        id2parent[i] = int(p) if p is not None else None
    children = {}
    for i, p in id2parent.items():
        children.setdefault(p, []).append(i)
    root_candidates = [i for i, p in id2parent.items() if p is None]
    root = max(root_candidates, key=lambda i: len(children.get(i, [])))

    # 深度：从根做广度优先遍历（BFS）
    depth = {root: 0}
    queue = [root]
    while queue:
        cur = queue.pop(0)
        for c in children.get(cur, []):
            depth[c] = depth[cur] + 1
            queue.append(c)
    return {"id2name": id2name, "id2acr": id2acr, "id2parent": id2parent,
            "children": children, "root": root, "depth": depth}


def descendants(graph, root_id):
    """root_id 及其全部子孙的编号集合（查isocortex子树用）。"""
    out, queue = {root_id}, [root_id]
    while queue:
        cur = queue.pop()
        for c in graph["children"].get(cur, []):
            if c not in out:
                out.add(c)
                queue.append(c)
    return out


def coord_to_voxel(coord, dim, sign):
    """一条坐标(μm) → 体素下标。sign=-1 表示该轴整体翻转；出界返回-1。"""
    i = int(round(coord / VOXEL_UM))
    if i < 0 or i >= dim:
        return -1
    return i if sign == 1 else dim - 1 - i


def xyz_to_region(xyz, vol, perm, signs):
    """一个点(μm) → 脑区编号。perm决定数据三轴各对应图谱哪一轴，
    signs决定每轴是否翻转。任何一轴出界都判为 OUTSIDE(0)。"""
    idx = []
    for vax in range(3):
        i = coord_to_voxel(xyz[perm[vax]], vol.shape[vax], signs[vax])
        if i < 0:
            return OUTSIDE
        idx.append(i)
    return int(vol[idx[0], idx[1], idx[2]])


def regions_for_points(xyz, vol, perm, signs):
    """一批点 (N,3) → (N,) 脑区编号数组（矢量化版，全量数据用）。

    和 xyz_to_region 完全同一个映射规则，只是把逐点循环换成
    numpy 批量运算：整批点一次算出体素下标，再用花式索引一次查完。
    出界的点判为 OUTSIDE(0)。
    """
    xyz = np.asarray(xyz, dtype=float)
    ok = np.ones(len(xyz), dtype=bool)
    idx = np.empty((len(xyz), 3), dtype=np.int64)
    for vax in range(3):
        i = np.rint(xyz[:, perm[vax]] / VOXEL_UM).astype(np.int64)
        if signs[vax] == -1:
            i = vol.shape[vax] - 1 - i
        ok &= (i >= 0) & (i < vol.shape[vax])
        # 越界的先夹到范围内占位（防止花式索引报错），最后统一改回 OUTSIDE
        idx[:, vax] = np.clip(i, 0, vol.shape[vax] - 1)
    labels = vol[idx[:, 0], idx[:, 1], idx[:, 2]]
    labels[~ok] = OUTSIDE
    return labels


def scan_orientation(points, vol, cortex_ids=None):
    """轴向自检：48种映射（3轴排列 × 每轴正反2种）逐个打分。

    依据的最强证据：全皮层数据集的胞体必须落在皮层里。
    有层级表时分数 = 落在 isocortex 子树的比例；没有时 = 落在脑内的比例。
    返回按分数从高到低排的列表。
    """
    from itertools import permutations, product
    results = []
    for perm in permutations(range(3)):
        for signs in product((1, -1), repeat=3):
            labels = [xyz_to_region(p, vol, perm, signs) for p in points]
            if cortex_ids:
                score = float(np.mean([l in cortex_ids for l in labels]))
            else:
                score = float(np.mean([l != OUTSIDE for l in labels]))
            results.append({"score": score, "perm": perm, "signs": signs,
                            "labels": labels})
    results.sort(key=lambda r: -r["score"])
    return results
