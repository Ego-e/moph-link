"""P3 第二步：树突特征增量模型（B3 / B4 + 单特征表）。

对照设计（大纲拍板版）：
  B3-树突：只用树突特征（不带位置/层）→ 形态的独立价值（all100 可跑，不依赖 S2）
  B4-拼接：位置 + 层 + 树突（labeled82，层来自 Table S2）
  B2b-kNN-z：位置+层（P2 最优 0.2869），本脚本用同一划分重算，保证同折配对
  归因 Δ = cos(B2b-kNN-z) − cos(B4-kNN-z)，Δ>0.01 → 树突有增量（预钉，负结果也成立）
  单特征表：每个特征单独 kNN，5 折 cos + LOSO 对 B0 胜场 x/7（只排序不断言）

特征处理：log1p 压重尾（逐元素变换，不含任何统计量，无泄漏），
NaN 用全表中位数插补（中位数不带标签信息，无泄漏），
标准化参数照旧只从训练折算。

怎么跑：python src/p3_models.py（依赖 outputs/dendrite_features.csv）
产出：outputs/p3_report.csv / p3_summary.csv / p3_single_feature.csv / p3_verdict.txt
"""
import numpy as np
import pandas as pd
from sklearn.model_selection import GroupKFold

from baselines import OUT, cosine_dist, js_dist, top5_hit, predict_b0, \
    ridge_fit_predict, knn_fit_predict, pick_k
from robustness import load_data, z_fit, z_apply, onehot_layer
from dendrite_features import FEATURE_NAMES

LOG1P = ["total_length", "n_nodes", "n_bif", "n_tips", "max_radial", "z_extent"]
XYZ = ["soma_x", "soma_y", "soma_z"]
THRESH = 0.01   # 预钉的增量判读阈值（与 P2 层判据同口径）


def build_block(df_part, kinds, tr, te):
    """按 block 需求拼特征矩阵，标准化参数只从训练折算。"""
    mats_tr, mats_te = [], []
    for kind in kinds:
        if kind == "coords":
            C = df_part[XYZ].values
            mu, sd = z_fit(C[tr])
            mats_tr.append(z_apply(C[tr], mu, sd))
            mats_te.append(z_apply(C[te], mu, sd))
        elif kind == "layer":
            oh = onehot_layer(df_part["SomaLayer"].fillna("unknown"))
            mats_tr.append(oh[tr])
            mats_te.append(oh[te])
        elif kind == "dend":
            D = df_part[FEATURE_NAMES].values.astype(float)
            mu, sd = z_fit(D[tr])
            mats_tr.append(z_apply(D[tr], mu, sd))
            mats_te.append(z_apply(D[te], mu, sd))
    return np.hstack(mats_tr), np.hstack(mats_te)


def run_cv(df_part, Y_part, blocks, rows, cohort):
    """5 折 GroupKFold：每折跑 B0 + 指定 block 的 kNN/ridge，逐神经元记成绩。"""
    for tr, te in GroupKFold(n_splits=5).split(df_part,
                                               groups=df_part["sample_id"]):
        Y_tr, Y_te = Y_part[tr], Y_part[te]
        preds = {"B0-平均": np.tile(predict_b0(Y_tr), (len(te), 1))}
        for name, kinds in blocks.items():
            Xtr, Xte = build_block(df_part, kinds, tr, te)
            k = pick_k(Xtr, Y_tr)
            preds[f"{name}-kNN-z"] = knn_fit_predict(Xtr, Y_tr, Xte, k)
            preds[f"{name}-ridge-z"] = ridge_fit_predict(Xtr, Y_tr, Xte)
        for j, i in enumerate(te):
            for bname, P in preds.items():
                rows.append({"cohort": cohort,
                             "sample_id": int(df_part.iloc[i]["sample_id"]),
                             "neuron_id": int(df_part.iloc[i]["neuron_id"]),
                             "baseline": bname,
                             "cos": cosine_dist(P[j], Y_te[j]),
                             "js": js_dist(P[j], Y_te[j]),
                             "top5": top5_hit(P[j], Y_te[j])})


def run_loso(df_part, Y_part, blocks):
    """留一样本：每个 block 逐样本的 mean cos（对 B0 的逐样本比较）。"""
    rows = []
    for sid in sorted(df_part["sample_id"].unique()):
        te = df_part.index[df_part["sample_id"] == sid].values
        tr = df_part.index[df_part["sample_id"] != sid].values
        Y_tr, Y_te = Y_part[tr], Y_part[te]
        preds = {"B0-平均": np.tile(predict_b0(Y_tr), (len(te), 1))}
        for name, kinds in blocks.items():
            Xtr, Xte = build_block(df_part, kinds, tr, te)
            k = pick_k(Xtr, Y_tr)
            preds[f"{name}-kNN-z"] = knn_fit_predict(Xtr, Y_tr, Xte, k)
        for bname, P in preds.items():
            rows.append({"holdout_sample": int(sid),
                         "baseline": bname,
                         "cos_mean": float(np.mean(
                             [cosine_dist(P[j], Y_te[j]) for j in range(len(te))]))})
    return pd.DataFrame(rows)


def main():
    df, Y = load_data()
    feat = pd.read_csv(OUT / "dendrite_features.csv")
    df = df.merge(feat, on=["sample_id", "neuron_id"], how="left")
    # 中位数插补：中位数不含标签信息，不构成泄漏
    for f in FEATURE_NAMES:
        df[f] = df[f].fillna(df[f].median())
    for c in LOG1P:                      # 压重尾：长度/计数类先 log1p
        df[c] = np.log1p(df[c])

    rows = []
    run_cv(df, Y, {"B3": ["dend"]}, rows, "all100")
    has_s2 = "SomaLocation" in df.columns and df["SomaLocation"].notna().any()
    if has_s2:
        lab = df[df["SomaLocation"].notna()].reset_index(drop=True)
        Y_lab = Y[df["SomaLocation"].notna()]
        run_cv(lab, Y_lab, {"B2b": ["coords", "layer"], "B3": ["dend"],
                            "B4": ["coords", "layer", "dend"]}, rows, "labeled82")
    else:
        lab, Y_lab = None, None
        print("无 Table S2，只跑 all100 的 B0/B3")

    res = pd.DataFrame(rows)
    res.to_csv(OUT / "p3_report.csv", index=False)
    summ = res.groupby(["cohort", "baseline"])[["cos", "js", "top5"]] \
        .agg(["mean", "std"]).round(4)
    summ.columns = [f"{m}_{s}" for m, s in summ.columns]
    summ.to_csv(OUT / "p3_summary.csv")

    # ---- LOSO（B4 vs B0，逐样本）----
    loso = run_loso(lab, Y_lab, {"B4": ["coords", "layer", "dend"]}) if has_s2 else None
    if loso is not None:
        loso.to_csv(OUT / "p3_loso_B4.csv", index=False)

    # ---- 单特征表（all100，kNN：5 折 cos + LOSO 对 B0 胜场）----
    srows = []
    for f in FEATURE_NAMES:
        sub = df[["sample_id", f]].rename(columns={f: "feat_val"}).reset_index(drop=True)
        cos_cv, _, _ = single_feature_cv(sub, Y)
        win, n = single_feature_loso(sub, Y)
        srows.append({"feature": f, "cos_5fold": round(cos_cv, 4),
                      "loso_win_vs_B0": f"{win}/{n}"})
    single = pd.DataFrame(srows).sort_values("cos_5fold")
    single.to_csv(OUT / "p3_single_feature.csv", index=False)

    # ---- 结论文件 ----
    lines = ["P3 树突增量结论（p3_models.py 生成）", ""]
    if has_s2:
        g = res[res["cohort"] == "labeled82"].groupby("baseline")["cos"].mean()
        d_knn = g["B2b-kNN-z"] - g["B4-kNN-z"]
        d_rid = g["B2b-ridge-z"] - g["B4-ridge-z"]
        lines += [
            f"配对增量 Δ = cos(B2b) − cos(B4)（labeled82，5 折，同折配对）：",
            f"  kNN:   Δ = {d_knn:+.4f}    B2b {g['B2b-kNN-z']:.4f} → B4 {g['B4-kNN-z']:.4f}",
            f"  ridge: Δ = {d_rid:+.4f}",
            f"  判读标准（预钉）：Δ > {THRESH} → 树突有增量；|Δ| ≤ {THRESH} → 无增量（负结果也成立）",
            "",
        ]
        wide = loso.pivot(index="holdout_sample", columns="baseline",
                          values="cos_mean")
        diff = wide["B4-kNN-z"] - wide["B0-平均"]
        win = int((diff < 0).sum())
        lines += [
            f"LOSO（逐样本）：B4-kNN-z 优于 B0：{win}/{len(diff)}；"
            f"不优样本：{[int(s) for s in diff[diff >= 0].index]}",
            "",
        ]
    g100 = res[res["cohort"] == "all100"].groupby("baseline")["cos"].mean()
    lines += [
        f"纯形态价值（all100，5 折）：B0 {g100['B0-平均']:.4f} → B3-kNN-z {g100['B3-kNN-z']:.4f}"
        f"（Δ = {g100['B0-平均'] - g100['B3-kNN-z']:+.4f}）",
        "",
        "单特征 Top5（all100，5 折 cos，越低越有用；LOSO 列=对 B0 胜场）：",
        single.head(5).to_string(index=False),
        "",
        "明细见 p3_summary.csv / p3_single_feature.csv / p3_report.csv"
        + (" / p3_loso_B4.csv" if has_s2 else ""),
    ]
    (OUT / "p3_verdict.txt").write_text("\n".join(lines), encoding="utf-8")
    print("已写入 outputs/: p3_report.csv, p3_summary.csv, p3_single_feature.csv, "
          "p3_verdict.txt" + (", p3_loso_B4.csv" if has_s2 else ""))


def single_feature_cv(sub, Y):
    """单特征 5 折 kNN 的平均 cos。sub: sample_id + feat_val。"""
    cos_list = []
    for tr, te in GroupKFold(n_splits=5).split(sub, groups=sub["sample_id"]):
        F = sub[["feat_val"]].values
        mu, sd = z_fit(F[tr])
        Xtr, Xte = z_apply(F[tr], mu, sd), z_apply(F[te], mu, sd)
        P = knn_fit_predict(Xtr, Y[tr], Xte, pick_k(Xtr, Y[tr]))
        cos_list += [cosine_dist(P[j], Y[te[j]]) for j in range(len(te))]
    return float(np.mean(cos_list)), None, None


def single_feature_loso(sub, Y):
    """单特征 LOSO：逐样本与该折 B0 比，返回 (胜场, 总样本数)。"""
    win = n = 0
    for sid in sorted(sub["sample_id"].unique()):
        te = sub.index[sub["sample_id"] == sid].values
        tr = sub.index[sub["sample_id"] != sid].values
        Y_tr, Y_te = Y[tr], Y[te]
        F = sub[["feat_val"]].values
        mu, sd = z_fit(F[tr])
        P = knn_fit_predict(z_apply(F[tr], mu, sd), Y_tr,
                            z_apply(F[te], mu, sd), pick_k(z_apply(F[tr], mu, sd), Y_tr))
        cos_f = float(np.mean([cosine_dist(P[j], Y_te[j]) for j in range(len(te))]))
        cos_b0 = float(np.mean([cosine_dist(predict_b0(Y_tr), y) for y in Y_te]))
        n += 1
        win += int(cos_f < cos_b0)
    return win, n


if __name__ == "__main__":
    main()
