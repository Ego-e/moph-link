"""P3 增补：折内特征选择（B3s / B4s）+ 样本量→特征数规则。

规则（预钉，一次性，不许再调）与经验地基（2026-11-17 文献回顾）：
  k_feat = max(2, min(可用特征数, n_train // 10))
  口径=样本/参数（ML 界 VC 维经验≈10×参数量），非 EPV——分布回归没有二元
  事件数可数，EPV"分母按事件数"的钉子（Peduzzi 1996, J Clin Epidemiol）
  不适用，此为已注明的口径偏离。
  10-15 区间：Harrell 主张 15；Riley 2016 指出 1:10 无理论依据（PMC5122171），
  故 n//15、n//20 作敏感性档，预钉档仍为 10（先注册，避免看结果调参）。
  特征高相关时 √N 方向适用（Hua 等）：实测相关性在 verdict 里；
  n_train≈66 → √66≈8，三档 k_feat=6/4/4 均在界内。
  规则只当预检，最终裁判是交叉验证；全量 1.8 万时上限 1800，规则不束缚全量。

选择准则（全部在训练折内完成，测试折不参与，零泄漏）：
  折内把全部特征标准化 → 每个特征单独跑折内 LOO kNN
  （k 由 pick_k 折内选）→ 按 cos 升序（越低越有用）取前 k_feat 个。

特征池自动扩展：outputs/polarity_features.csv 存在则把极性族并入
  （与 p3_scan / p3_forward 同款），保证与贪心版同池可比。

模型：
  B3s = 选出的 k_feat 个树突特征（all100 也可跑）
  B4s = 位置 + 层 + 选出的特征（labeled82）
  与 B2b 同折重算配对；全 15 特征版 B4 的数字从 p3_summary.csv 读来对照。

怎么跑：python src/p3_select.py（依赖 outputs/dendrite_features.csv）
产出：outputs/p3sel_report.csv / p3sel_summary.csv / p3sel_selection.csv
      / p3sel_loso.csv / p3sel_verdict.txt
"""
import numpy as np
import pandas as pd
from sklearn.model_selection import GroupKFold

from baselines import OUT, cosine_dist, js_dist, top5_hit, predict_b0, \
    ridge_fit_predict, knn_fit_predict, pick_k
from robustness import load_data, z_fit, z_apply, onehot_layer
from dendrite_features import FEATURE_NAMES
from p3_models import LOG1P, XYZ, THRESH

MIN_FEAT = 2
FEAT_PER_SAMPLE = 10   # 预钉档：每特征至少 10 个训练样本
RULES = [("n//10 (预钉)", 10), ("n//15 (敏感性)", 15), ("n//20 (敏感性)", 20)]


def n_feat_rule(n_train, n_avail, div=FEAT_PER_SAMPLE):
    """样本量→特征数。div=10 为预钉档；15/20 仅作敏感性检查。"""
    return max(MIN_FEAT, min(n_avail, n_train // div))


def loo_cos(col, Y):
    """单特征折内 LOO cos：k 先由 pick_k 折内选，再用该 k 逐样本留一。"""
    n = len(Y)
    k = pick_k(col, Y)
    errs = []
    for i in range(n):
        tr = np.delete(np.arange(n), i)
        P = knn_fit_predict(col[tr], Y[tr], col[[i]], k)
        errs.append(cosine_dist(P[0], Y[i]))
    return float(np.mean(errs))


def select_in_fold(Dz_tr, Y_tr, k_feat):
    """折内按单特征 LOO cos 排序（升序=越有用），取前 k_feat。返回 (索引, 得分)。"""
    scores = np.array([loo_cos(Dz_tr[:, [j]], Y_tr)
                       for j in range(Dz_tr.shape[1])])
    order = np.argsort(scores)
    return order[:k_feat], scores


def load_features(df):
    """合并树突特征；极性族产物存在则自动并入。返回 (df, 特征名列表)。"""
    feat = pd.read_csv(OUT / "dendrite_features.csv")
    df = df.merge(feat, on=["sample_id", "neuron_id"], how="left")
    feats = list(FEATURE_NAMES)
    pol = OUT / "polarity_features.csv"
    if pol.exists():
        from polarity_features import POLARITY_NAMES
        df = df.merge(pd.read_csv(pol), on=["sample_id", "neuron_id"], how="left")
        feats += POLARITY_NAMES
    for f in feats:
        df[f] = df[f].fillna(df[f].median())
    for c in [c for c in LOG1P if c in feats]:
        df[c] = np.log1p(df[c])
    return df, feats


def eval_fold(df, Y, tr, te, with_pos, cohort, feats):
    """一个折：折内选特征 → 各基线评估。返回 (rows, sel_names)。"""
    Y_tr = Y[tr]
    C = df[XYZ].values
    mu, sd = z_fit(C[tr])
    Cz_tr, Cz_te = z_apply(C[tr], mu, sd), z_apply(C[te], mu, sd)
    D = df[feats].values.astype(float)
    mu, sd = z_fit(D[tr])
    Dz_tr, Dz_te = z_apply(D[tr], mu, sd), z_apply(D[te], mu, sd)
    if with_pos:
        oh = onehot_layer(df["SomaLayer"].fillna("unknown"))
        oh_tr, oh_te = oh[tr], oh[te]

    # 折内特征有用性排序：算分一次，三档规则共用同一排序（排序不受规则影响）
    _, scores = select_in_fold(Dz_tr, Y_tr, D.shape[1])
    order = np.argsort(scores)

    def pack(sel_tr, sel_te):
        if with_pos:
            return (np.hstack([Cz_tr, oh_tr, sel_tr]),
                    np.hstack([Cz_te, oh_te, sel_te]))
        return sel_tr, sel_te

    base = "B4s" if with_pos else "B3s"
    preds = {}
    sel_names = None
    for label, div in RULES:
        k_f = n_feat_rule(len(tr), D.shape[1], div)
        s = order[:k_f]
        if div == FEAT_PER_SAMPLE:
            sel_names = [feats[j] for j in s]   # 预钉档进选择日志
        tag = "" if div == FEAT_PER_SAMPLE else f"@{div}"
        Xtr, Xte = pack(Dz_tr[:, s], Dz_te[:, s])
        preds[f"{base}-kNN-z{tag}"] = knn_fit_predict(
            Xtr, Y_tr, Xte, pick_k(Xtr, Y_tr))
        if div == FEAT_PER_SAMPLE:   # ridge 只挂预钉档
            preds[f"{base}-ridge-z"] = ridge_fit_predict(Xtr, Y_tr, Xte)
    if with_pos:
        Xb_tr, Xb_te = pack(Dz_tr[:, :0], Dz_te[:, :0])
        preds["B2b-kNN-z"] = knn_fit_predict(
            Xb_tr, Y_tr, Xb_te, pick_k(Xb_tr, Y_tr))
        preds["B2b-ridge-z"] = ridge_fit_predict(Xb_tr, Y_tr, Xb_te)
    preds["B0-平均"] = np.tile(predict_b0(Y_tr), (len(te), 1))

    rows = []
    for j, i in enumerate(te):
        for bname, P in preds.items():
            rows.append({"cohort": cohort,
                         "sample_id": int(df.iloc[i]["sample_id"]),
                         "neuron_id": int(df.iloc[i]["neuron_id"]),
                         "baseline": bname,
                         "cos": cosine_dist(P[j], Y[i]),
                         "js": js_dist(P[j], Y[i]),
                         "top5": top5_hit(P[j], Y[i])})
    return rows, sel_names


def run(df, Y, with_pos, cohort, rows, sel_log, feats):
    """5 折 GroupKFold，逐折调用 eval_fold。"""
    for tr, te in GroupKFold(n_splits=5).split(df, groups=df["sample_id"]):
        r, sel = eval_fold(df, Y, tr, te, with_pos, cohort, feats)
        rows += r
        sel_log.append({"cohort": cohort, "split": "5fold",
                        "n_train": int(len(tr)), "k_feat": len(sel),
                        "selected": ";".join(sel)})


def main():
    df, Y = load_data()
    df, feats = load_features(df)
    nf = len(feats)

    rows, sel_log = [], []
    run(df.reset_index(drop=True), Y, False, "all100", rows, sel_log, feats)
    lab = df[df["SomaLocation"].notna()].reset_index(drop=True)
    Y_lab = Y[df["SomaLocation"].notna()]
    run(lab, Y_lab, True, "labeled82", rows, sel_log, feats)

    # ---- LOSO（labeled82）----
    loso_rows = []
    for sid in sorted(lab["sample_id"].unique()):
        te = lab.index[lab["sample_id"] == sid].values
        tr = lab.index[lab["sample_id"] != sid].values
        r, sel = eval_fold(lab, Y_lab, tr, te, True, "labeled82-LOSO", feats)
        loso_rows += r
        sel_log.append({"cohort": "labeled82", "split": f"LOSO-{int(sid)}",
                        "n_train": int(len(tr)), "k_feat": len(sel),
                        "selected": ";".join(sel)})

    res = pd.DataFrame(rows)
    res.to_csv(OUT / "p3sel_report.csv", index=False)
    (res.groupby(["cohort", "baseline"])[["cos", "js", "top5"]]
     .agg(["mean", "std"]).round(4)).to_csv(OUT / "p3sel_summary.csv")
    sel_df = pd.DataFrame(sel_log)
    sel_df.to_csv(OUT / "p3sel_selection.csv", index=False)

    lo = pd.DataFrame(loso_rows)
    w = lo.groupby(["sample_id", "baseline"])["cos"].mean().unstack()
    w["B4s−B0"] = (w["B4s-kNN-z"] - w["B0-平均"]).round(4)
    w.to_csv(OUT / "p3sel_loso.csv")

    # 特征相关性（经验规则的形状钉子：高相关→√N 方向，Hua 等）
    corr = df[feats].corr().abs().values
    iu = np.triu_indices(nf, 1)
    c_mean, c_max = float(corr[iu].mean()), float(corr[iu].max())
    c_n80 = int((corr[iu] > 0.8).sum())

    # ---- verdict ----
    m5 = res[res["cohort"] == "labeled82"].groupby("baseline")["cos"].mean()
    m100 = res[res["cohort"] == "all100"].groupby("baseline")["cos"].mean()
    d_knn = m5["B2b-kNN-z"] - m5["B4s-kNN-z"]
    d_ridge = m5["B2b-ridge-z"] - m5["B4s-ridge-z"]
    freq = (sel_df.query("cohort == 'labeled82'")["selected"]
            .str.split(";").explode().value_counts())
    ref = ""
    try:
        p2 = pd.read_csv(OUT / "p3_summary.csv")
        b4 = float(p2[(p2["cohort"] == "labeled82")
                      & (p2["baseline"] == "B4-kNN-z")]["cos_mean"].iloc[0])
        ref = f"（对照：全 15 特征版 B4-kNN-z {b4:.4f}）"
    except Exception:
        ref = "（p3_summary.csv 未读到，全特征版对照数字见其 verdict）"
    # 规则敏感性：Δ 随分母档位
    sens = []
    n5 = int(4 * len(lab) / 5)
    for label, div in RULES:
        kf = n_feat_rule(n5, nf, div)
        key = "B4s-kNN-z" if div == FEAT_PER_SAMPLE else f"B4s-kNN-z@{div}"
        sens.append((label, kf, m5["B2b-kNN-z"] - m5[key]))

    win = int((w["B4s−B0"] < 0).sum())
    sqn = int(round(np.sqrt(n5)))
    pool_note = f"{nf} 个（15 树突{'+' + str(nf - 15) + ' 极性' if nf > 15 else '，无极性产物'}）"
    lines = [
        "P3 折内选择版结论（p3_select.py 生成）", "",
        f"特征池：{pool_note}",
        "样本量→特征数规则（预钉）：k_feat = max(2, min(可用特征数, n_train // 10))",
        "  经验地基（口径钉子）：本规则是样本/参数（VC式经验≈10×参数量），",
        "  不是 EPV——分布回归无二元事件数可数，EPV 按事件数算分母的钉子",
        "  （Peduzzi 1996, pubmed 8970487）不适用，此为已注明的口径偏离。",
        f"  实际：5 折 labeled82 n_train≈{n5} → k_feat={n_feat_rule(n5, nf)}；"
        f"LOSO={n_feat_rule(len(lab) - len(lab)//7, nf)}；all100="
        f"{n_feat_rule(int(4 * len(df) / 5), nf)}",
        f"特征相关性（all100，两两|Pearson r|，{nf}×{nf} 共 {nf*(nf-1)//2} 对）："
        f"均值 {c_mean:.2f}，最大 {c_max:.2f}，|r|>0.8 的对数 {c_n80}/{nf*(nf-1)//2}",
        f"  → 高相关时 √N 方向适用（Hua 等）：√{n5}≈{sqn}，三档 k_feat 均在此界内", "",
        "规则敏感性（labeled82，5 折，Δ = B2b−B4s-kNN）：",
        *[f"  {label}: k_feat={kf}, Δ={d:+.4f}" for label, kf, d in sens], "",
        "配对增量（labeled82，5 折，同折配对，B2b 同折重算）：",
        f"  kNN:   Δ(B2b−B4s) = {d_knn:+.4f}    B2b {m5['B2b-kNN-z']:.4f} → B4s {m5['B4s-kNN-z']:.4f} {ref}",
        f"  ridge: Δ(B2b−B4s) = {d_ridge:+.4f}", "",
        f"纯形态（all100，5 折）：B0 {m100['B0-平均']:.4f} → B3s-kNN-z {m100['B3s-kNN-z']:.4f}", "",
        f"LOSO（labeled82）：B4s 优于 B0：{win}/{len(w)}；不优样本："
        f"{[int(s) for s in w[w['B4s−B0'] >= 0].index] or '无'}", "",
        f"选择频次（labeled82，共 {int((sel_df['cohort'] == 'labeled82').sum())} 次选择，预钉档）：",
        freq.to_string(), "",
        f"判读（预钉）：Δ > {THRESH} → 树突(选择后)有增量；|Δ| ≤ {THRESH} → 无增量。",
        "  规则只当预检，最终裁判是交叉验证（AAAMLP p.14 纲领）；",
        "  选择在折内完成、增量由未见折判定，结构上已满足。",
        "明细：p3sel_summary.csv / p3sel_selection.csv / p3sel_loso.csv / p3sel_report.csv",
    ]
    (OUT / "p3sel_verdict.txt").write_text("\n".join(lines), encoding="utf-8")
    print("已写入 outputs/: p3sel_report.csv, p3sel_summary.csv, "
          "p3sel_selection.csv, p3sel_loso.csv, p3sel_verdict.txt")


if __name__ == "__main__":
    main()
