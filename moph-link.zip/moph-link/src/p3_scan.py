"""P0-1 全模型扫描表〔v2框架 Step 5；TA 2026-11-19 拍板 all100 也扫〕。

两个 cohort：
  morph100: all100 纯形态（15[+6]特征，无坐标无层）——回答"无位置时哪个
            模型最能榨形态信息"（与 B3 同特征口径）
  full82:   labeled82 坐标+层+特征（=B4 特征集）——回答"加形态后模型族排序"
统一 5 折 GroupKFold（与全项目同划分）。每模型记：
  train cos（折内 in-sample，诊断过拟合）/ test cos / 逐神经元 std / 耗时。
判读〔MLCV 口径〕：3×STD 带内不可比；深挖只挑 2-3 个。

特征池自动扩展：outputs/polarity_features.csv 存在则把极性族并入。

怎么跑：python src/p3_scan.py（sklearn 收敛警告已静音）
产出：outputs/p3scan_report.csv / p3scan_folds.csv / p3scan_verdict.txt
"""
import time
import warnings
warnings.filterwarnings("ignore")          # MLP/Lasso 收敛警告噪声，扫描阶段无关

import numpy as np
import pandas as pd
from sklearn.model_selection import GroupKFold
from sklearn.dummy import DummyRegressor
from sklearn.linear_model import Ridge, Lasso, ElasticNet
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import (RandomForestRegressor, ExtraTreesRegressor,
                              GradientBoostingRegressor)
from sklearn.multioutput import MultiOutputRegressor
from sklearn.svm import SVR
from sklearn.neural_network import MLPRegressor

from baselines import OUT, cosine_dist, knn_fit_predict, pick_k
from robustness import load_data, z_fit, z_apply, onehot_layer
from dendrite_features import FEATURE_NAMES
from p3_models import LOG1P, XYZ


def load_features(df):
    """合并树突特征；极性族产物存在则自动并入。返回 (df, 特征名列表)。"""
    feat = pd.read_csv(OUT / "dendrite_features.csv")
    df = df.merge(feat, on=["sample_id", "neuron_id"], how="left")
    feats = list(FEATURE_NAMES)
    pol = OUT / "polarity_features.csv"
    if pol.exists():
        from polarity_features import POLARITY_NAMES
        df = df.merge(pd.read_csv(pol), on=["sample_id", "neuron_id"], how="left")
        feats += POLARITY_NAMES
    for f in feats:
        df[f] = df[f].fillna(df[f].median())
    for c in [c for c in LOG1P if c in feats]:
        df[c] = np.log1p(df[c])
    return df, feats


def model_zoo():
    """候选模型（默认超参为主；ridge 给三档 α 做迷你敏感性）。"""
    return {
        "dummy_均值":      DummyRegressor(strategy="mean"),          # = B0 锚
        "ridge_a1":        Ridge(alpha=1.0),
        "ridge_a10":       Ridge(alpha=10.0),                        # baselines 同款
        "ridge_a100":      Ridge(alpha=100.0),
        "lasso_a0.1":      Lasso(alpha=0.1, max_iter=50000),
        "enet_a0.1_r0.5":  ElasticNet(alpha=0.1, l1_ratio=0.5, max_iter=50000),
        "kNN_pick_k":      None,                                     # k 由 pick_k 折内选
        "决策树":           DecisionTreeRegressor(random_state=0),
        "rf_300":          RandomForestRegressor(n_estimators=300, random_state=0, n_jobs=-1),
        "et_300":          ExtraTreesRegressor(n_estimators=300, random_state=0, n_jobs=-1),
        "gb":              MultiOutputRegressor(GradientBoostingRegressor(random_state=0)),
        "svr_rbf":         MultiOutputRegressor(SVR(kernel="rbf")),
        "svr_linear":      MultiOutputRegressor(SVR(kernel="linear")),
        "mlp_64":          MLPRegressor(hidden_layer_sizes=(64,), max_iter=3000,
                                        random_state=0),
    }


def scan(df, Y, feats, with_pos, cohort, nrow, frow):
    """一个 cohort 的 5 折 × 全模型扫描。"""
    F = df[feats].values.astype(float)
    for fi, (tr, te) in enumerate(GroupKFold(n_splits=5).split(
            df, groups=df["sample_id"])):
        mu, sd = z_fit(F[tr])
        Fz = z_apply(F, mu, sd)
        blocks_tr, blocks_te = [], []
        if with_pos:
            C = df[XYZ].values
            mu2, sd2 = z_fit(C[tr])
            Cz = z_apply(C, mu2, sd2)
            oh = onehot_layer(df["SomaLayer"].fillna("unknown"))
            blocks_tr += [Cz[tr], oh[tr]]
            blocks_te += [Cz[te], oh[te]]
        blocks_tr.append(Fz[tr])
        blocks_te.append(Fz[te])
        Xtr, Xte = np.hstack(blocks_tr), np.hstack(blocks_te)
        Ytr = Y[tr]
        for name, model in model_zoo().items():
            t0 = time.time()
            if name == "kNN_pick_k":
                k = pick_k(Xtr, Ytr)
                Ptr = knn_fit_predict(Xtr, Ytr, Xtr, k)   # in-sample，诊断过拟合
                Pte = knn_fit_predict(Xtr, Ytr, Xte, k)
            else:
                model.fit(Xtr, Ytr)
                Ptr, Pte = model.predict(Xtr), model.predict(Xte)
            sec = time.time() - t0
            frow.append({"cohort": cohort, "model": name, "fold": fi,
                         "train_cos": float(np.mean([cosine_dist(Ptr[j], Ytr[j])
                                                     for j in range(len(Ytr))])),
                         "sec": round(sec, 2)})
            for j, i in enumerate(te):
                nrow.append({"cohort": cohort, "model": name,
                             "sample_id": df.iloc[i]["sample_id"],
                             "neuron_id": df.iloc[i]["neuron_id"],
                             "cos": cosine_dist(Pte[j], Y[i])})


def main():
    df, Y = load_data()
    df, feats = load_features(df.reset_index(drop=True))
    lab_mask = df["SomaLocation"].notna()

    nrow, frow = [], []
    scan(df, Y, feats, False, "morph100", nrow, frow)
    scan(df[lab_mask].reset_index(drop=True),
         Y[lab_mask], feats, True, "full82", nrow, frow)

    res = pd.DataFrame(nrow)
    fdf = pd.DataFrame(frow)
    res.to_csv(OUT / "p3scan_report.csv", index=False)
    fdf.to_csv(OUT / "p3scan_folds.csv", index=False)

    lines = ["P0-1 全模型扫描（p3_scan.py 生成）", "",
             f"特征池：{len(feats)} 个"
             f"（15 树突{'+6 极性' if len(feats) > 15 else ''}）", ""]
    for cohort in ["morph100", "full82"]:
        g = (res[res["cohort"] == cohort].groupby("model")["cos"]
             .agg(["mean", "std"]).sort_values("mean"))
        t = fdf[fdf["cohort"] == cohort].groupby("model")[
            ["train_cos", "sec"]].mean()
        best = float(g["mean"].min())
        std_best = float(g["std"].iloc[0])
        band = [m for m in g.index if g.loc[m, "mean"] <= best + 3 * std_best]
        lines += [f"== {cohort}（按 test cos 升序，越低越好）=="]
        lines.append(f"{'模型':<16}{'test cos':>10}{'std':>8}{'train cos':>11}"
                     f"{'gap':>9}{'秒/折':>7}  带内")
        for m, row in g.iterrows():
            lines.append(f"{m:<16}{row['mean']:>10.4f}{row['std']:>8.4f}"
                         f"{t.loc[m, 'train_cos']:>11.4f}"
                         f"{t.loc[m, 'train_cos'] - row['mean']:>9.4f}"
                         f"{t.loc[m, 'sec']:>7.2f}"
                         f"{'✓' if m in band else ''}")
        lines += ["", f"3×STD 带内（与最优不可分）：{'、'.join(band)}", ""]
    lines += ["判读〔MLCV 口径〕：带内模型不可比；深挖只挑 2-3 个。",
              "关注：kNN_pick_k 与 ridge_a10 的排名差是否在带内（P3 口径分裂",
              "是普遍现象还是这两模型的特例）；树族是否系统性压过线性族。"]
    (OUT / "p3scan_verdict.txt").write_text("\n".join(lines), encoding="utf-8")
    print("已写 outputs/p3scan_report.csv, p3scan_folds.csv, p3scan_verdict.txt")


if __name__ == "__main__":
    main()
