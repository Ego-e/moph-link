"""练手A第二步·下：轴向验证 + 标签矩阵第一版（路径自适应版）

目录结构（根目录整体移动不影响代码，代码里不写死任何绝对路径）：
  <root>/inputs/data/raw/   数据（SWC + annotation_25.nrrd + ccf_structure_graph.json）
  <root>/src/               本文件等代码
  <root>/notebooks/         交互分析（暂空）
  <root>/outputs/           manifest 与全部产出

跑法：cd <root> 后 python src/build_labels.py

性能版：全量1.5万级可用——两遍流式（读一个算一个扔一个，不驻留点云），
查脑区用矢量化批量查（atlas_io.regions_for_points），自检抽样≤1000。
"""
from collections import Counter  # noqa: F401  (保留给交互调试用)

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import swc_io
from swc_io import SwcNeuron, TYPE_AXON, resolve_swc
import atlas_io
from atlas_io import (load_annotation, load_graph, descendants,
                      scan_orientation, regions_for_points, OUTSIDE)

# ---- 根路径：沿用 swc_io 里的定义（src/ 的上一级），根目录搬到哪都不受影响 ----
ROOT = swc_io.ROOT
RAW_DIR = ROOT / "inputs" / "data" / "raw"
OUT_DIR = ROOT / "outputs"
FIG_DIR = OUT_DIR / "figures"

ATLAS_PATH = RAW_DIR / "annotation_25.nrrd"
GRAPH_PATH = RAW_DIR / "ccf_structure_graph.json"
MANIFEST = OUT_DIR / "subset_manifest.csv"

AGG_DEPTH = 3      # 非皮层脑区的聚合深度（根=0）。皮层区固定聚到"群"一级
MIN_SCORE = 0.8    # 标定映射命中率低于它就不自动采纳，停下来人工判读

# ---- 标定结果（calibrate_space.py 2026-11-16：82胞体 98.8% 命中各自官方脑区）----
# 轴序实测结论：x=前后轴，y=上下轴（脑背面向下），z=左右轴（编号不分半球，
# 所以左右镜像不影响判区；z 全部落在一个半球内，具体哪侧未定）
CAL_PERM = (0, 1, 2)
CAL_SIGNS = (1, 1, 1)


def main():
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    vol, _ = load_annotation(ATLAS_PATH)
    print("图谱形状(体素):", vol.shape,
          "=", tuple(round(v * atlas_io.VOXEL_UM) for v in vol.shape), "μm")

    graph = None
    if GRAPH_PATH.exists():
        graph = load_graph(GRAPH_PATH)
        print(f"层级表加载成功：{len(graph['id2name'])} 个脑区，"
              f"根节点 = {graph['id2name'][graph['root']]}")
    else:
        print("未找到层级表json → 没有脑区名称，轴向打分退化为'是否落脑内'。")
        print("用压缩包里的 ccf_structure_graph.json（全量1327项版），")

    # isocortex 编号不硬编码：在层级表里按缩写找（现版本体里是 315，
    # 旧版才有 993；表里没有就退回"落脑内"判据）
    cortex_ids = None
    iso_id = None
    if graph:
        iso = [i for i, a in graph["id2acr"].items() if a.lower() == "isocortex"]
        if iso:
            iso_id = iso[0]
            cortex_ids = descendants(graph, iso_id)

    # 第一遍流式扫描：只留胞体坐标，不驻留神经元点云（全量1.5万个也只占几十KB）
    manifest = pd.read_csv(MANIFEST)
    somas = []
    print(f"第一遍：扫描 {len(manifest)} 个文件，收集胞体坐标...")
    for _, row in manifest.iterrows():
        points, _ = swc_io.parse_swc(resolve_swc(row["full_path"]))
        somas.append(SwcNeuron(points, source=row["full_path"]).soma_xyz)
    somas = np.array(somas, dtype=float)
    print(f"已读取 {len(somas)} 个胞体坐标")

    # ---- 轴向自检（只打印，不再决定用哪个映射；抽样≤1000个，全量数据也秒级）----
    if len(somas) > 1000:
        rng = np.random.default_rng(0)
        scan_pts = somas[rng.choice(len(somas), 1000, replace=False)]
    else:
        scan_pts = somas
    ranked = scan_orientation(scan_pts, vol, cortex_ids)
    lines = [f"score={r['score']:.3f}  perm={r['perm']}  signs={r['signs']}"
             for r in ranked[:5]]
    print("\n轴向映射前5名（自检用）：")
    print("\n".join(lines))
    (OUT_DIR / "axis_check.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")

    # ---- 采纳标定映射，自检发现更高映射时提醒 ----
    perm, signs = CAL_PERM, CAL_SIGNS
    cal_labels = regions_for_points(somas, vol, perm, signs)
    ref = cortex_ids if cortex_ids else None
    cal_score = float(np.mean([l in ref for l in cal_labels])) if ref \
        else float(np.mean(cal_labels != OUTSIDE))
    if ranked[0]["score"] > cal_score + 0.01:
        print("\n提醒：自检出现比标定映射更高的映射，标定结果可能过期 → 停下人工判读。")
        return
    if cal_score < MIN_SCORE:
        print(f"\n标定映射命中率 {cal_score:.3f} 不达标 → 已停。把 axis_check.txt 发我。")
        return
    print(f"\n采纳标定映射 perm={perm} signs={signs}，命中率 {cal_score:.3f}")

    if graph:
        def name_of(i):
            if i == OUTSIDE:
                return "outside"
            return graph["id2name"].get(i, f"id{i}")
    else:
        def name_of(i):
            return "outside" if i == OUTSIDE else f"id{i}"

    # ---- 大区归属 ----
    # 皮层叶子（各层）→ 爬到 Isocortex 的直接子区（"区"一级，如 SSp-bfd）；
    # 非皮层叶子 → 沿父链爬到 AGG_DEPTH 深度（保持原行为）
    def big_region(leaf):
        if graph is None:
            return leaf
        a = leaf
        if iso_id is not None and a in cortex_ids and a != iso_id:
            while graph["id2parent"].get(a) not in (None, iso_id):
                a = graph["id2parent"][a]
            return a
        while graph["depth"].get(a, 0) > AGG_DEPTH \
                and graph["id2parent"].get(a) is not None:
            a = graph["id2parent"][a]
        return a

    # ---- 第二遍流式打标签：读一个、算一个、扔一个，内存只占单个神经元的量级 ----
    # 矢量化查脑区：每个神经元的轴突点云一次性批量查完（不再逐点Python循环）
    soma_rows, leaf_rows, big_counts = [], [], {}
    for i, row in enumerate(manifest.itertuples(index=False), 1):
        points, _ = swc_io.parse_swc(resolve_swc(row.full_path))
        n = SwcNeuron(points, source=row.full_path)

        s_lab = int(regions_for_points(n.soma_xyz[None, :], vol, perm, signs)[0])
        soma_rows.append({"sample_id": row.sample_id, "neuron_id": row.neuron_id,
                          "region_id": s_lab, "region": name_of(s_lab),
                          "soma_x": n.soma_xyz[0], "soma_y": n.soma_xyz[1],
                          "soma_z": n.soma_xyz[2]})

        axon_pts = n.type_xyz(TYPE_AXON)
        if len(axon_pts):
            labs = regions_for_points(axon_pts, vol, perm, signs)
            uids, cnts = np.unique(labs, return_counts=True)
            bigc = {}
            for lid, c in zip(uids.tolist(), cnts.tolist()):
                leaf_rows.append((row.sample_id, row.neuron_id, lid, c))
                b = big_region(lid)
                bigc[b] = bigc.get(b, 0) + c
            big_counts[(row.sample_id, row.neuron_id)] = bigc

        if i % 500 == 0:
            print(f"  打标签进度 {i}/{len(manifest)}")

    pd.DataFrame(soma_rows).to_csv(OUT_DIR / "labels_soma.csv", index=False)
    pd.DataFrame(leaf_rows,
                 columns=["sample_id", "neuron_id", "region_id", "count"]
                 ).to_csv(OUT_DIR / "axons_leaf_counts.csv", index=False)

    # ---- 大区标签矩阵 ----
    all_big = sorted({b for c in big_counts.values() for b in c} | {OUTSIDE})
    mat_rows = []
    for (s, nid), c in big_counts.items():
        tot = sum(c.values())
        if tot == 0:
            continue
        mat_rows.append({"sample_id": s, "neuron_id": nid,
                         **{name_of(b): c.get(b, 0) / tot for b in all_big}})
    pd.DataFrame(mat_rows).to_csv(OUT_DIR / "axons_big_matrix.csv", index=False)

    # ---- 胞体脑区分布图 ----
    key = "region" if graph else "region_id"
    counts = pd.DataFrame(soma_rows)[key].value_counts()
    fig, ax = plt.subplots(figsize=(11, 5))
    counts.plot(kind="bar", ax=ax)
    ax.set_ylabel("neurons")
    ax.set_title(f"Soma regions (n={len(soma_rows)})")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "soma_regions.png", dpi=150)
    plt.close(fig)

    print("\n===== 标签构建摘要 =====")
    print("胞体脑区分布：")
    print(counts.to_string())
    print(f"\n大区标签矩阵：{len(mat_rows)} 行 × {len(all_big)} 列 → axons_big_matrix.csv")
    print("大区列名（皮层已聚到群一级；非皮层按AGG_DEPTH聚合，可调重跑）：")
    print([name_of(b) for b in all_big])


if __name__ == "__main__":
    main()
