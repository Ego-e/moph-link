"""P0-2 贪心前向选择 v2〔方法五精度矩阵精神；书外延伸，标〔新增〕〕。

与 p3_select.py（边际 top-k）同折配对：
  边际排序的问题：强共线家族抱团——n_nodes/n_bif/n_tips/total_length 一起
  挤进前 k，选出的是"一群冗余兄弟"，不是"互补维度"。

贪心准则（全在训练折内完成，零泄漏；预钉）：
  起始集合 = 位置 + 层（等价于"在 B2b 上做前向增量"）；
  每步在"当前集合 + 候选 j"上算折内 LOO cos，选使 cos 最小的候选；
  每步的 k 由当前集合 pick_k 选一次（不逐候选调参——省时且保证同一步内
  各候选在同一个 k 下公平比较）；
  不做早停，选满样本量规则给的 k_feat（trace 里自己看拐点）。

特征池自动扩展：outputs/polarity_features.csv 存在则并入（与 p3_scan 同款）。

怎么跑：python src/p3_forward.py（依赖 outputs/dendrite_features.csv）
产出：outputs/p3fwd_report.csv / p3fwd_selection.csv / p3fwd_loso.csv
      / p3fwd_verdict.txt
"""
import numpy as np
import pandas as pd
from sklearn.model_selection import GroupKFold

from baselines import OUT, cosine_dist, predict_b0, ridge_fit_predict, \
    knn_fit_predict, pick_k
from robustness import load_data, z_fit, z_apply, onehot_layer
from p3_models import XYZ, THRESH
from p3_select import n_feat_rule
from p3_scan import load_features


def greedy_select(Fz_tr, base_tr, Y_tr, k_feat, feat_names):
    """折内贪心前向。base_tr = 位置+层（固定块）。返回 (入选列索引, trace)。"""
    n = len(Y_tr)
    remaining = list(range(Fz_tr.shape[1]))
    chosen, trace = [], []
    for step in range(k_feat):
        blocks = [base_tr] + ([Fz_tr[:, chosen]] if chosen else [])
        cur = np.hstack(blocks)
        k = pick_k(cur, Y_tr)                # 每步选一次 k，步内所有候选共用
        best_j, best_s = None, np.inf
        for j in remaining:
            Xj = np.hstack([cur, Fz_tr[:, [j]]])
            errs = []
            for i in range(n):
                tr = np.delete(np.arange(n), i)
                Pj = knn_fit_predict(Xj[tr], Y_tr[tr], Xj[[i]], k)
                errs.append(cosine_dist(Pj[0], Y_tr[i]))
            s = float(np.mean(errs))
            if s < best_s:
                best_s, best_j = s, j
        chosen.append(best_j)
        remaining.remove(best_j)
        trace.append({"step": step + 1, "picked": feat_names[best_j],
                      "loo_cos": round(best_s, 4)})
    return chosen, trace


def eval_fold(df, Y, tr, te, feats, cohort):
    """一个折：贪心选特征 → B4f（坐标+层+选集）与 B2b 同折评估。"""
    Y_tr = Y[tr]
    F = df[feats].values.astype(float)
    C = df[XYZ].values
    mu, sd = z_fit(F[tr]); Fz_tr, Fz_te = z_apply(F[tr], mu, sd), z_apply(F[te], mu, sd)
    mu2, sd2 = z_fit(C[tr]); Cz_tr, Cz_te = z_apply(C[tr], mu2, sd2), z_apply(C[te], mu2, sd2)
    oh = onehot_layer(df["SomaLayer"].fillna("unknown"))
    oh_tr, oh_te = oh[tr], oh[te]
    base_tr, base_te = np.hstack([Cz_tr, oh_tr]), np.hstack([Cz_te, oh_te])

    k_feat = n_feat_rule(len(tr), len(feats))
    chosen, trace = greedy_select(Fz_tr, base_tr, Y_tr, k_feat, feats)

    Xtr = np.hstack([base_tr, Fz_tr[:, chosen]])
    Xte = np.hstack([base_te, Fz_te[:, chosen]])
    preds = {
        "B4f-kNN-z": knn_fit_predict(Xtr, Y_tr, Xte, pick_k(Xtr, Y_tr)),
        "B4f-ridge-z": ridge_fit_predict(Xtr, Y_tr, Xte),
        "B2b-kNN-z": knn_fit_predict(base_tr, Y_tr, base_te, pick_k(base_tr, Y_tr)),
        "B2b-ridge-z": ridge_fit_predict(base_tr, Y_tr, base_te),
        "B0-平均": np.tile(predict_b0(Y_tr), (len(te), 1)),
    }
    rows = []
    for j, i in enumerate(te):
        for bname, P in preds.items():
            rows.append({"cohort": cohort, "sample_id": df.iloc[i]["sample_id"],
                         "neuron_id": df.iloc[i]["neuron_id"], "baseline": bname,
                         "cos": cosine_dist(P[j], Y[i])})
    sel = [feats[j] for j in chosen]
    return rows, sel, trace


def main():
    df, Y = load_data()
    df, feats = load_features(df.reset_index(drop=True))
    lab = df[df["SomaLocation"].notna()].reset_index(drop=True)
    Y_lab = Y[df["SomaLocation"].notna()]

    rows, sel_log, trace_log = [], [], []
    # 5 折
    for tr, te in GroupKFold(n_splits=5).split(lab, groups=lab["sample_id"]):
        r, sel, trace = eval_fold(lab, Y_lab, tr, te, feats, "labeled82")
        rows += r
        sel_log.append({"split": "5fold", "n_train": int(len(tr)),
                        "k_feat": len(sel), "selected": ";".join(sel)})
        trace_log.append({"split": "5fold", **{f"step{t['step']}": t["picked"]
                                               for t in trace}})
    res = pd.DataFrame(rows)
    res.to_csv(OUT / "p3fwd_report.csv", index=False)

    # LOSO
    loso_rows = []
    for sid in sorted(lab["sample_id"].unique()):
        te = lab.index[lab["sample_id"] == sid].values
        tr = lab.index[lab["sample_id"] != sid].values
        r, sel, trace = eval_fold(lab, Y_lab, tr, te, feats, "labeled82-LOSO")
        loso_rows += r
        sel_log.append({"split": f"LOSO-{int(sid)}", "n_train": int(len(tr)),
                        "k_feat": len(sel), "selected": ";".join(sel)})
        trace_log.append({"split": f"LOSO-{int(sid)}",
                          **{f"step{t['step']}": t["picked"] for t in trace}})
    sel_df = pd.DataFrame(sel_log)
    sel_df.to_csv(OUT / "p3fwd_selection.csv", index=False)
    pd.DataFrame(trace_log).to_csv(OUT / "p3fwd_trace.csv", index=False)
    lo = pd.DataFrame(loso_rows)
    w = lo.groupby(["sample_id", "baseline"])["cos"].mean().unstack()
    w["B4f−B0"] = (w["B4f-kNN-z"] - w["B0-平均"]).round(4)
    w.to_csv(OUT / "p3fwd_loso.csv")

    # ---- verdict ----
    m5 = res[res["cohort"] == "labeled82"].groupby("baseline")["cos"].mean()
    d_knn = m5["B2b-kNN-z"] - m5["B4f-kNN-z"]
    d_ridge = m5["B2b-ridge-z"] - m5["B4f-ridge-z"]
    ref = ""
    try:
        p2 = pd.read_csv(OUT / "p3sel_summary.csv", header=[0, 1], index_col=[0, 1])
        b4s = float(p2.loc[("labeled82", "B4s-kNN-z"), ("cos", "mean")])
        ref = f"（边际版 B4s-kNN-z = {b4s:.4f}，同折可比）"
    except Exception:
        ref = "（p3sel_summary.csv 未读到，边际版对照见其 verdict）"
    win = int((w["B4f−B0"] < 0).sum())
    tr_df = pd.DataFrame(trace_log)
    step_cols = [c for c in tr_df.columns if c.startswith("step")]
    lines = [
        "P0-2 贪心前向选择结论（p3_forward.py 生成）", "",
        f"特征池：{len(feats)} 个；k_feat = max(2, min(n_train//10, 池大小))",
        "  预钉：起始=位置+层；每步折内 LOO cos 选增量最大候选；每步 k 共用；",
        "  不早停。与边际版 B4s 的差别=选法（条件增量 vs 边际排序）。", "",
        "配对增量（labeled82，5 折，同折配对，B2b 同折重算）：",
        f"  kNN:   Δ(B2b−B4f) = {d_knn:+.4f}    B2b {m5['B2b-kNN-z']:.4f} → B4f {m5['B4f-kNN-z']:.4f} {ref}",
        f"  ridge: Δ(B2b−B4f) = {d_ridge:+.4f}", "",
        f"LOSO：B4f 优于 B0：{win}/{len(w)}；不优样本："
        f"{[int(s) for s in w[w['B4f−B0'] >= 0].index] or '无'}", "",
        "贪心入选顺序（每列一折，看前几步谁先被选）：",
        tr_df[["split"] + step_cols].to_string(index=False), "",
        f"判读（预钉）：Δ > {THRESH} → 树突(贪心选择后)有增量；"
        f"|Δ| ≤ {THRESH} → 无增量。",
        "明细：p3fwd_report.csv / p3fwd_selection.csv / p3fwd_trace.csv",
    ]
    (OUT / "p3fwd_verdict.txt").write_text("\n".join(lines), encoding="utf-8")
    print("已写 outputs/p3fwd_report.csv, p3fwd_selection.csv, p3fwd_trace.csv, "
          "p3fwd_loso.csv, p3fwd_verdict.txt")


if __name__ == "__main__":
    main()
