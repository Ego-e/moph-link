"""P0-前置（待TA一句话拍板）：极性特征族提取〔冠军方法四：弱信息单列成族〕。

族内 6 个特征（预钉，一次性，不许再调）：
  has_apical       是否存在顶树突主干（0/1）
  apical_len_frac  顶树突子树长度占比
  apical_node_frac 顶树突子树节点占比
  apical_reach     顶树突最大 pia 向位移（μm）
  trunk_dominance  最长根分支子树长度占比（符号无关）
  y_anisotropy     段长垂直度 Σ|Δy|/Σ段长（符号无关）

坐标系依赖（钉子）：只需要上下轴 y。2026-11-17 标定笔记：轴序 x前后/y上下/
z左右，"背面向下" → pia 方向 = −y，即 PIA_SIGN = −1。
AP 前后与左右半球两个悬案这里用不上——极性不依赖它们。

待确认（一句话）：PIA_SIGN = −1 对不对？
  方向反了的后果：has_apical / apical_len_frac / apical_node_frac /
  apical_reach 四个特征会系统性把基树突选成"顶树突"；
  trunk_dominance / y_anisotropy 两个符号无关特征不受影响——
  这就是族里放两个符号无关特征的原因。

判定规则（预钉，简单优先）：
  胞体每个根子树算 max(PIA_SIGN·(y − y_soma))；取最大者当"顶树突候选"，
  最大值 > APICAL_MIN_REACH (30μm) 才算 has_apical=1，否则 0。
  小树（<50 节点）全 NaN，与 dendrite_features 同口径。

怎么跑：python src/polarity_features.py（依赖 outputs/subset_manifest.csv）
产出：outputs/polarity_features.csv / polarity_qc.txt
下游：p3_scan.py 与 p3_forward.py 检测到本产物后自动把 6 列并入特征池。
"""
import os
import traceback

import numpy as np
import pandas as pd
from scipy.stats import spearmanr

from swc_io import parse_swc, resolve_swc, TYPE_SOMA, TYPE_DEND
from dendrite_features import MANIFEST, OUT_DIR, build_tree, MIN_DEND_NODES

# 双符号对照跑法：PIA_SIGN=+1 python src/polarity_features.py
# 默认 −1 只是初值，82 样本层级标尺没定案（check_pia_sign 3:4 + 旁证 rho≈0），
# 最终以双符号 has_apical 对照 + 全量层级标尺为准。
PIA_SIGN = float(os.environ.get("PIA_SIGN", "-1.0"))
APICAL_MIN_REACH = 30.0  # μm；最大pia向位移低于此不认顶树突

POLARITY_NAMES = ["has_apical", "apical_len_frac", "apical_node_frac",
                  "apical_reach", "trunk_dominance", "y_anisotropy"]


def extract_polarity(path):
    """一个 dend 文件 → (极性特征字典, QC 字典)。异常由调用方抓。"""
    points, _ = parse_swc(resolve_swc(path))
    types = points[:, 1].astype(int)
    keep = (types == TYPE_SOMA) | (types == TYPE_DEND)
    pts = points[keep]
    t = pts[:, 1].astype(int)
    n_dend = int((t == TYPE_DEND).sum())
    if n_dend < MIN_DEND_NODES:
        return ({f: np.nan for f in POLARITY_NAMES},
                {"n_dend": n_dend, "flag": f"树突过小({n_dend}节点)"})

    children, roots, n_dangling = build_tree(pts)
    xyz = pts[:, 2:5]                      # 列 0=x, 1=y(上下), 2=z
    n = len(pts)
    soma_idx = next((i for i in range(n) if t[i] == TYPE_SOMA),
                    roots[0] if roots else 0)
    parent_idx = np.full(n, -1)
    for u, cs in children.items():
        for c in cs:
            parent_idx[c] = u

    # 拓扑序（迭代栈，与 dendrite_features 同款）
    order, stack = [], list(reversed(roots))
    while stack:
        u = stack.pop()
        order.append(u)
        stack.extend(reversed(children[u]))

    # 段长与段 dy（y 轴增量）
    seg_len = np.zeros(n)
    seg_dy = np.zeros(n)
    for u in order:
        p = parent_idx[u]
        if p < 0:
            continue
        d = xyz[u] - xyz[p]
        seg_len[u] = np.linalg.norm(d)
        seg_dy[u] = d[1]

    # 子树归属：每个节点属于胞体的哪个直接子分支（序号）
    root_children = list(children.get(soma_idx, []))
    rc = np.full(n, -1)
    for i, c in enumerate(root_children):
        rc[c] = i
    for u in order:                        # 父先于子，向下传播
        if rc[u] < 0 and parent_idx[u] >= 0:
            rc[u] = rc[parent_idx[u]]

    # 子树累计长度 / 子树最大 pia 向位移（后序向根传播）
    slen = seg_len.copy()
    val = PIA_SIGN * (xyz[:, 1] - xyz[soma_idx, 1])
    mval = val.copy()
    for u in reversed(order):
        p = parent_idx[u]
        if p >= 0:
            slen[p] += slen[u]
            mval[p] = max(mval[p], mval[u])

    tot_len = float(seg_len.sum())
    total_dy = float(np.abs(seg_dy).sum())

    gap = np.nan
    feats = {"trunk_dominance": np.nan, "y_anisotropy": np.nan,
             "has_apical": 0.0, "apical_len_frac": 0.0,
             "apical_node_frac": 0.0, "apical_reach": 0.0}
    trunk_stats = []
    if root_children:
        sl = np.array([slen[c] for c in root_children])
        mv = np.array([mval[c] for c in root_children])
        trunk_stats = list(zip(sl.tolist(), mv.tolist()))
        feats["trunk_dominance"] = float(sl.max() / max(tot_len, 1e-9))
        feats["y_anisotropy"] = float(total_dy / max(tot_len, 1e-9))
        reach_sorted = np.sort(mv)[::-1]
        gap = float(reach_sorted[0] - reach_sorted[1]) if len(reach_sorted) > 1 \
            else float(reach_sorted[0])
        best_i = int(np.argmax(mv))
        best_c = root_children[best_i]
        # 【改】2026-11-20：原判据"max pia向位移>30μm"在真实尺度恒真
        # （双符号 has_apical 都 100%，QC 实测），失效。改为 reach-gap：
        # 最向 pia 的 trunk 超出次名 trunk 的距离 > APICAL_MIN_REACH 才算
        # 明确顶树突——锥体 signature 是"一根 trunk 明显越过其余所有
        # trunk"，不是"有 trunk 向上爬"。错误符号下基树突丛对称、gap 小，
        # 故 has_apical 率本身也变成符号判别器。
        if gap > APICAL_MIN_REACH:
            feats["has_apical"] = 1.0
            feats["apical_len_frac"] = float(slen[best_c] / max(tot_len, 1e-9))
            feats["apical_node_frac"] = float((rc == best_i).sum() / n)
            feats["apical_reach"] = float(mval[best_c])

    qc = {"n_dend": n_dend, "n_dangling": n_dangling,
          "n_trunks": len(root_children), "reach_gap": gap,
          "trunk_stats": trunk_stats,
          "flag": "" if (t == TYPE_SOMA).any() else "缺胞体(用第一根当参考)"}
    return feats, qc


def main():
    man = pd.read_csv(MANIFEST)
    rows, qcs, trunk_stats = [], [], []
    first_tb = None                            # 首例异常完整栈，定位用
    for r in man.itertuples():
        try:
            feats, qc = extract_polarity(r.dend_path)
            qc["ok"] = True
        except Exception as e:                     # 读不了点名，不悄悄跳过
            if first_tb is None:
                first_tb = traceback.format_exc()
            feats = {f: np.nan for f in POLARITY_NAMES}
            qc = {"n_dend": np.nan, "n_dangling": np.nan, "n_trunks": np.nan,
                  "reach_gap": np.nan, "trunk_stats": [],
                  "flag": f"读取失败:{type(e).__name__}: {e}", "ok": False}
        rows.append({"sample_id": r.sample_id, "neuron_id": r.neuron_id, **feats})
        trunk_stats.extend(qc.pop("trunk_stats", []))
        qcs.append({"sample_id": r.sample_id, "neuron_id": r.neuron_id, **qc})

    feat_df = pd.DataFrame(rows)
    qc_df = pd.DataFrame(qcs)
    feat_df.to_csv(OUT_DIR / "polarity_features.csv", index=False)
    qc_df.to_csv(OUT_DIR / "polarity_qc.csv", index=False)   # 失败原因落盘，别再吞
    if first_tb is not None:
        (OUT_DIR / "polarity_fail_trace.txt").write_text(first_tb, encoding="utf-8")
    ok = qc_df[qc_df["ok"]]
    bad = qc_df[~qc_df["ok"]]

    lines = [
        "极性特征族 QC（polarity_features.py 生成）", "",
        f"实际使用的 PIA_SIGN = {PIA_SIGN:+.0f}",
        f"提取成功 {len(ok)}/{len(qc_df)}，失败 {len(bad)}",
    ]
    if len(ok):
        lines += [
            f"断链节点总数（预期0）：{ok['n_dangling'].sum():.0f}",
            f"根分支数（每神经元 trunk 数）：中位 {ok['n_trunks'].median():.0f}，"
            f"最大 {ok['n_trunks'].max():.0f}",
            f"reach_gap（顶候选超出次名 trunk 的距离）：中位 {ok['reach_gap'].median():.1f} μm",
            f"has_apical=1（reach-gap 判据）：{int(feat_df['has_apical'].sum())}/{len(feat_df)} "
            f"({feat_df['has_apical'].mean():.0%})",
            f"apical_len_frac：中位 {feat_df['apical_len_frac'].median():.2f}，"
            f"最大 {feat_df['apical_len_frac'].max():.2f}",
            f"trunk_dominance：中位 {feat_df['trunk_dominance'].median():.2f}",
            f"y_anisotropy：中位 {feat_df['y_anisotropy'].median():.2f}",
        ]
        if len(trunk_stats) > 10:
            arr = np.array(trunk_stats)
            rho_pool, p_pool = spearmanr(arr[:, 0], arr[:, 1])
            lines += [
                f"池化判据：{len(arr)} 根 trunk 的（子树长度 vs pia向位移）"
                f"Spearman rho={rho_pool:+.3f}（p={p_pool:.1e}）",
                "  正相关=最长 trunk 最向该方向爬 → 该方向是 pia（锥体 signature）",
                "  双符号对照裁决：reach_gap 与 apical_len_frac 差异大的一边；"
                "池化 rho 有 trunk 尺寸混淆（长trunk在任何轴上都伸得远），"
                "2026-11-20 实测双符号都≈+0.47，只作参考",
            ]
        else:
            lines += ["池化判据：trunk 样本不足，缺席"]
    if len(bad):
        lines += ["", "失败原因分布："]
        lines += [f"  {k}: {v}" for k, v in bad["flag"].value_counts().items()]
        lines += ["", f"首例异常完整栈 → outputs/polarity_fail_trace.txt"]
    if len(ok) == 0:
        lines += ["", "全部失败——先看失败原因分布与 fail_trace，不要往下跑 p3_scan/p3_forward。"]
    lines += ["", "下游：p3_scan.py 与 p3_forward.py 检测到 polarity_features.csv 后自动并入；",
              "全 NaN 的列会让 sklearn 响亮报错（这是故意的护栏，不是静默污染）。"]
    (OUT_DIR / "polarity_qc.txt").write_text("\n".join(lines), encoding="utf-8")
    print("已写 outputs/polarity_features.csv, polarity_qc.txt")


if __name__ == "__main__":
    main()
