"""用官方标签校准坐标空间（Table S2 当标尺）——判定版。

思路：Table S2 给了每个神经元的官方胞体脑区（CCF缩写）。
坐标映射正确时，每个神经元的胞体坐标必须落进它自己的官方脑区里。
流程：
  A. 缩写→编号查对（查不到的当场点名，不再静默）
  B. 48 种排列翻转逐个试"落进自己官方脑区"
  C. 都不达标 → 用官方脑区质心差估平移，再在 ±1.5mm 网格精搜
  D. 还不行 → 打印坐标范围 vs 脑实际范围对照，一眼看出差在哪根轴

输入（都放 inputs/data/raw/）：
  annotation_25.nrrd
  ccf_structure_graph.json
  table s2.xlsx          ← 文件名带 2 就行
  subset_manifest.csv    ← outputs/ 下 make_subset 生成的那份

用法：cd <root> 后 python src/calibrate_space.py
输出同时打到终端和 outputs/calibrate_report.txt，直接把文件发回来即可。
"""
import json
import sys
from itertools import permutations, product

import numpy as np
import pandas as pd

import swc_io
from swc_io import SwcNeuron, resolve_swc
import atlas_io
from atlas_io import load_annotation, load_graph, descendants, xyz_to_region, OUTSIDE

ROOT = swc_io.ROOT
RAW_DIR = ROOT / "inputs" / "data" / "raw"
OUT_DIR = ROOT / "outputs"


def find_s2():
    cands = [p for p in RAW_DIR.glob("*.xlsx") if "2" in p.stem.lower()]
    if len(cands) == 1:
        return cands[0]
    raise FileNotFoundError(f"找不到 Table S2，请放进 {RAW_DIR}（文件名里要有 2）")


def load_official_labels():
    """Table S2 → {(sample_id, neuron_id): SomaLocation缩写}（仅ISO项目）。"""
    s2 = pd.read_excel(find_s2())
    s2 = s2[s2["ProjectID"] == "ISO"]
    return {(int(str(r["SampleID"]).lstrip("S")),
             int(str(r["NeuronID"]).lstrip("N"))): str(r["SomaLocation"])
            for _, r in s2.iterrows()}


def hit_with_offset(mapped, vol, rids, subtrees, offset, voxel_um):
    """加平移后逐点查：命中自己官方脑区的个数。"""
    hit = 0
    for p, rid in zip(mapped, rids):
        idx = np.rint((p + offset) / voxel_um).astype(int)
        if all(0 <= idx[k] < vol.shape[k] for k in range(3)):
            if int(vol[idx[0], idx[1], idx[2]]) in subtrees[rid]:
                hit += 1
    return hit


def main():
    # 输出双写：终端 + outputs/calibrate_report.txt（发回这个文件就行）
    OUT_DIR.mkdir(exist_ok=True)
    report = OUT_DIR / "calibrate_report.txt"
    real_stdout = sys.stdout
    fout = open(report, "w", encoding="utf-8", buffering=1)

    class _Tee:
        def write(self, s):
            real_stdout.write(s)
            fout.write(s)

        def flush(self):
            real_stdout.flush()
            fout.flush()

    sys.stdout = _Tee()
    try:
        _run()
    finally:
        sys.stdout = real_stdout
        fout.close()
    print(f"完整输出已写入 {report}")


def _run():
    vol, _ = load_annotation(RAW_DIR / "annotation_25.nrrd")
    g = load_graph(RAW_DIR / "ccf_structure_graph.json")

    # 缩写→编号：直接从 json 重建，不依赖 atlas_io 版本
    #（上一版兜底把方向存反了，导致全部查不到——已废弃那条路）
    with open(RAW_DIR / "ccf_structure_graph.json", "r", encoding="utf-8") as f:
        raw = json.load(f)
    items = raw["msg"] if isinstance(raw, dict) and "msg" in raw else raw
    acr2id = {it["acronym"]: int(it["id"]) for it in items if it.get("acronym")}
    print(f"层级表共 {len(items)} 项，含缩写 {len(acr2id)} 个。抽查：")
    for s in ("MOs", "ACAd", "SSp-bfd", "PL", "VISp"):
        print(f"   {s} → {acr2id.get(s)}")

    official = load_official_labels()
    manifest = pd.read_csv(OUT_DIR / "subset_manifest.csv")

    # ---- A. 对标签 + 查编号（查不到的当场点名） ----
    pts, rids, acr_miss = [], [], []
    for _, row in manifest.iterrows():
        key = (int(row["sample_id"]), int(row["neuron_id"]))
        if key not in official:
            continue
        points, _ = swc_io.parse_swc(resolve_swc(row["full_path"]))
        n = SwcNeuron(points, source=row["full_path"])
        if n.soma_xyz is None:
            continue
        rid = acr2id.get(official[key])
        if rid is None:
            acr_miss.append(official[key])
            continue
        pts.append(np.asarray(n.soma_xyz, float))
        rids.append(rid)
    pts = np.array(pts)
    print(f"A. 官方标签+缩写都查到: {len(pts)} 个；缩写查不到编号: {len(acr_miss)} 个")
    if acr_miss:
        print(f"   查不到的缩写: {sorted(set(acr_miss))}")
    if len(pts) == 0:
        print("\n一个都查不到 → 大概率 json 不对（抽查行应显示编号而非 None）。"
              "先核对 ccf_structure_graph.json 是不是从 "
              "structure_graph_download/1.json 下载的原始文件。")
        return

    subtrees = {rid: descendants(g, rid) for rid in set(rids)}
    n = len(pts)

    # ---- B. 48 种映射 ----
    best = []
    for perm in permutations(range(3)):
        for signs in product((1, -1), repeat=3):
            hit = sum(xyz_to_region(p, vol, perm, signs) in subtrees[r]
                      for p, r in zip(pts, rids))
            best.append((hit / n, perm, signs))
    best.sort(reverse=True)
    print("\nB. 无平移：命中自己官方脑区 top5")
    for s, perm, signs in best[:5]:
        print(f"   score={s:.3f}  perm={perm}  signs={signs}")

    s0, perm, signs = best[0]
    if s0 >= 0.8:
        print(f"\n结论：无需平移。SWC列→图谱轴 perm={perm} signs={signs}。")
        return

    # ---- C. 质心差估平移 + 网格精搜 ----
    print(f"\nC. 无平移最优 {s0:.1%} < 80%，进入平移估计（映射 {perm}{signs}）")
    mapped = pts[:, list(perm)] * np.array(signs)
    cent = {}
    for rid in set(rids):
        mask = np.isin(vol, list(subtrees[rid]))
        if mask.sum():
            cent[rid] = np.argwhere(mask).mean(axis=0) * atlas_io.VOXEL_UM
    offset0 = (np.array([cent[r] for r in rids]).mean(axis=0)
               - mapped.mean(axis=0))
    print("   质心差估计平移(μm):", np.round(offset0, 0).tolist())

    hits0 = hit_with_offset(mapped, vol, rids, subtrees, offset0, atlas_io.VOXEL_UM)
    print(f"   直接用质心差平移: {hits0}/{n} = {hits0/n:.1%}")

    # 精搜：估计值附近 ±1.5mm、步长 100μm
    best_off, best_hit = offset0, hits0
    grid = np.arange(-1500, 1501, 100)
    for dx in grid:
        for dy in grid:
            for dz in grid:
                off = offset0 + np.array([dx, dy, dz])
                h = hit_with_offset(mapped, vol, rids, subtrees, off,
                                    atlas_io.VOXEL_UM)
                if h > best_hit:
                    best_hit, best_off = h, off
    print(f"   精搜最优: {best_hit}/{n} = {best_hit/n:.1%}")
    print("   精搜最优平移(μm):", np.round(best_off, 0).tolist())

    # ---- D. 还不行 → 范围对照 ----
    if best_hit / n < 0.8:
        nz = np.argwhere(vol != 0)
        print("\nD. 精搜仍不达标 → 范围对照（每根映射后轴，μm）")
        print("   体素图非零区（=脑实际在哪）:")
        for k in range(3):
            print(f"   轴{k}: {nz[:, k].min()*25} ~ {nz[:, k].max()*25}")
        print("   胞体坐标（映射后）:")
        for k in range(3):
            print(f"   轴{k}: {mapped[:, k].min():.0f} ~ {mapped[:, k].max():.0f}")
        print("\n把本文件全部输出发回来，重点看 B/C/D 三段。")
    else:
        print(f"\n结论：perm={perm} signs={signs} "
              f"offset={np.round(best_off, 0).tolist()}")


if __name__ == "__main__":
    main()
