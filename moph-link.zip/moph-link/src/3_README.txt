练手A：数据体检 + 标签构建（第一步 + 第二步合并版）
====================================================

五个脚本（全放 src/ 下，缺一不可）：
  swc_io.py       SWC读取解析 + 项目根路径定义 + manifest路径换算
  make_subset.py  第一步·扫描数据目录，挑100个三文件齐全的神经元 → manifest
  check_100.py    第一步·逐个体检 + 胞体分布图 + 单神经元线稿
  atlas_io.py     第二步·加载CCF脑区图 + 坐标查脑区 + 48种轴向映射自检
  build_labels.py 第二步·定轴向 + 打标签 + 大区标签矩阵

目录结构（本套代码的路径假设；根目录整体搬家代码一行不用改）
------------------------------------------------------------
  <root>/inputs/data/raw/    reg... 那堆SWC + annotation_25.nrrd + ccf_structure_graph.json
  <root>/src/                上面五个py
  <root>/notebooks/          暂空
  <root>/outputs/            manifest 与全部产出

数据文件清单（放 inputs/data/raw/）
------------------------------------
  SWC 三件套          axon/dend/full_full_recon-<SampleID>_<NeuronID>.txt
  annotation_25.nrrd  三维脑区编号图（25μm体素）
  ccf_structure_graph.json  脑区层级表——文件夹里已带（全量1327项版），
                      拷进 inputs/data/raw/ 即可，不要用 wget 下（那条
                      structure_graph_download 命令只返回根节点一个条目）
  table s2.xlsx       官方逐神经元标签表（胞体脑区/层/IT-PT-CT/亚型），
                      仅校准和标签核对用；注意 IT/PT/CT 与 Subtype 是
                      按轴突定义的，正式模型里严禁作为输入

怎么跑（在项目根 <root> 下，按顺序三步）
----------------------------------------
  conda activate morphology
  python src/make_subset.py     # ① 生成 manifest（新manifest存相对路径）
  python src/check_100.py       # ② 体检：解析成功率/断链/胞体分布/示例线稿
  python src/build_labels.py    # ③ 轴向验证 + 打标签 + 标签矩阵

环境：nrrd 包报 ModuleNotFoundError 就 pip install nrrd

诊断与校准：若 build_labels 报"命中率不达标"（axis_check 全 0 或偏低），
不用坐标瞎猜——官方 Table S2 自带每个神经元的胞体脑区，直接当标尺用：
  1. 把 table s2.xlsx 原样拷进 inputs/data/raw/（文件名不用改）
  2. python src/calibrate_space.py
  3. 输出自动写入 outputs/calibrate_report.txt（终端同步显示），
     把这个文件发回来即可

产出清单
--------
第一步（check_100）：
  outputs/check_100_report.csv            逐神经元体检指标
  outputs/figures/soma_distribution.png   100个胞体位置分布（坐标验证）
  outputs/figures/neuron_example_*.png    单神经元线稿（解析验证）
第二步（build_labels）：
  outputs/axis_check.txt                  轴向映射前5名打分表
  outputs/labels_soma.csv                 每个神经元的胞体脑区
  outputs/axons_leaf_counts.csv           轴突在叶子脑区的计数（长表）
  outputs/axons_big_matrix.csv            大区标签矩阵（行=神经元，列=大区，值=占比）
  outputs/figures/soma_regions.png        胞体脑区分布条形图

每步看什么
----------
① make_subset：应打印"三文件齐全"的神经元数（约1.5万量级）。
② check_100：解析成功率应100%，缺胞体/断链应为0；胞体分布图应落在
   合理坐标范围内。
③ build_labels：
   - 轴向映射前5名：正确映射（全皮层胞体落皮层）命中率应接近1.0且
     明显甩开其他47种；命中率 < 0.8 脚本自动停 → 发 axis_check.txt 给我判读。
   - 胞体脑区分布：应集中在几个皮层脑区（注射位点附近），第二重验证。
   - 大区列名：嫌粗/细改 build_labels.py 顶部的 AGG_DEPTH（默认2）重跑。

跑完发我：三步的终端全部输出 + 各张png
