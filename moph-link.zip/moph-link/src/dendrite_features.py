"""P3 第一步：从树突 SWC 提取形态特征（v1，15 个标量特征）。

设计约定（P3 大纲拍板版）：
  - 只用树突（manifest 的 dend 文件）；轴突相关的一切禁入（泄漏纪律）
  - 半径特征整族不用——降采样版半径疑似全是占位值 1，本脚本实测验证（风险1）
  - 只用相对自身胞体的特征（径向距离 / Sholl / 自身伸展）；
    绝对方向特征等 calibrate 轴向定稿后再加（风险2）
  - 树突过小（<50 节点）的神经元特征标 NaN，在 QC 里点名（风险4）

特征四族（15 个）：
  规模  total_length / n_nodes / n_bif / n_tips / mean_seg_len / max_radial
  Sholl sholl_peak / sholl_r_crit / sholl_auc / sholl_slope（胞体为球心，10μm 步长）
  拓扑  bif_imbalance / bif_angle_mean / branch_order_entropy
  深度  z_extent / z_offset

怎么跑：python src/dendrite_features.py（读 outputs/subset_manifest.csv）
产出：outputs/dendrite_features.csv  逐神经元特征
      outputs/dendrite_qc.txt        质量检查（风险1/4 的验证证据）
"""
from collections import defaultdict
import numpy as np
import pandas as pd

from swc_io import parse_swc, resolve_swc, ROOT, TYPE_SOMA, TYPE_DEND

OUT_DIR = ROOT / "outputs"
MANIFEST = OUT_DIR / "subset_manifest.csv"
SHOLL_DR = 10.0        # Sholl 球壳步长（μm）
MIN_DEND_NODES = 50    # 树突节点低于此数 → 特征标 NaN，QC 点名

FEATURE_NAMES = [
    "total_length", "n_nodes", "n_bif", "n_tips", "mean_seg_len", "max_radial",
    "sholl_peak", "sholl_r_crit", "sholl_auc", "sholl_slope",
    "bif_imbalance", "bif_angle_mean", "branch_order_entropy",
    "z_extent", "z_offset",
]


def build_tree(pts):
    """点集 → (children 映射, 根列表, 断链数)。

    断链的节点按根处理并计数（P1 体检预期为 0，QC 里复核）。
    """
    ids = pts[:, 0].astype(int)
    parents = pts[:, 6].astype(int)
    id2idx = {pid: i for i, pid in enumerate(ids)}
    children = defaultdict(list)
    roots, n_dangling = [], 0
    for i, pid in enumerate(parents):
        if pid == -1:
            roots.append(i)
        elif pid in id2idx:
            children[id2idx[pid]].append(i)
        else:
            roots.append(i)          # 父节点缺失：当根挂起，QC 计数
            n_dangling += 1
    return children, roots, n_dangling


def extract_features(path):
    """一个 dend 文件 → (特征字典, QC 字典)。异常时由调用方抓。"""
    points, _ = parse_swc(resolve_swc(path))
    types = points[:, 1].astype(int)
    keep = (types == TYPE_SOMA) | (types == TYPE_DEND)
    pts = points[keep]
    t = pts[:, 1].astype(int)
    n_dend = int((t == TYPE_DEND).sum())

    qc = {"n_dend": n_dend,
          "radius_unique": ",".join(f"{v:g}" for v in np.unique(pts[:, 5]))}
    if n_dend < MIN_DEND_NODES:
        qc["flag"] = f"树突过小({n_dend}节点)"
        return {f: np.nan for f in FEATURE_NAMES}, qc

    children, roots, n_dangling = build_tree(pts)
    xyz = pts[:, 2:5]
    n = len(pts)
    parent_idx = np.full(n, -1)
    for u, cs in children.items():
        for c in cs:
            parent_idx[c] = u

    # 树遍历（迭代栈，防深树递归爆栈）：从每个根出发铺满森林
    soma_idx = next((i for i in range(n) if t[i] == TYPE_SOMA),
                    roots[0] if roots else 0)
    order, stack = [], list(reversed(roots))
    while stack:
        u = stack.pop()
        order.append(u)
        stack.extend(reversed(children[u]))

    L = np.zeros(n)      # 距胞体的累计路径长（μ m）
    B = np.zeros(n, int) # 分支序：每过一个分叉 +1
    for u in order:
        p = parent_idx[u]
        if p < 0:
            continue
        L[u] = L[p] + np.linalg.norm(xyz[u] - xyz[p])
        B[u] = B[p] + (1 if len(children[p]) >= 2 else 0)

    sizes = np.ones(n)   # 子树节点数（后序累加）
    for u in reversed(order):
        if parent_idx[u] >= 0:
            sizes[parent_idx[u]] += sizes[u]

    # ---- 规模族 ----
    seg = L[[u for u in order if parent_idx[u] >= 0]] - \
          L[[parent_idx[u] for u in order if parent_idx[u] >= 0]]
    total_length = float(seg.sum())
    n_bif = int(sum(len(cs) >= 2 for cs in children.values()))
    n_tips = int(sum(len(cs) == 0 for cs in children.values()))
    d_soma = np.linalg.norm(xyz - xyz[soma_idx], axis=1)
    max_radial = float(d_soma.max())
    mean_seg_len = total_length / max(len(seg), 1)

    # ---- Sholl 族（球壳穿越计数：子-父段两端径向距离夹住壳半径）----
    e_p = np.array([parent_idx[u] for u in order if parent_idx[u] >= 0])
    e_c = np.array([u for u in order if parent_idx[u] >= 0])
    d1, d2 = d_soma[e_p], d_soma[e_c]
    radii = np.arange(SHOLL_DR, max_radial + SHOLL_DR, SHOLL_DR)
    counts = ((d1[None, :] - radii[:, None]) *
              (d2[None, :] - radii[:, None]) < 0).sum(axis=1)
    if len(radii) >= 3:
        pk = int(counts.argmax())
        r_p, c_p = radii[pk:], counts[pk:]
        slope = float(np.polyfit(r_p, c_p, 1)[0]) if r_p.std() > 0 else np.nan
        sholl = {"sholl_peak": float(counts[pk]), "sholl_r_crit": float(radii[pk]),
                 "sholl_auc": float(counts.sum() * SHOLL_DR), "sholl_slope": slope}
    else:
        sholl = {k: np.nan for k in ("sholl_peak", "sholl_r_crit",
                                     "sholl_auc", "sholl_slope")}

    # ---- 拓扑族 ----
    angles, imbal = [], []
    for u, cs in children.items():
        if len(cs) == 2:
            v1 = xyz[cs[0]] - xyz[u]
            v2 = xyz[cs[1]] - xyz[u]
            denom = np.linalg.norm(v1) * np.linalg.norm(v2)
            if denom > 0:
                angles.append(np.degrees(np.arccos(
                    np.clip(np.dot(v1, v2) / denom, -1, 1))))
            s1, s2 = sizes[cs[0]], sizes[cs[1]]
            imbal.append(abs(s1 - s2) / (s1 + s2))
    hist = np.bincount(B[t == TYPE_DEND])
    p = hist[hist > 0] / hist.sum()
    entropy = float(-(p * np.log2(p)).sum())

    # ---- 深度剖面族 ----
    z = xyz[:, 2]
    z_extent = float(z.max() - z.min())
    z_offset = float(z.mean() - z[soma_idx])

    feats = {"total_length": total_length, "n_nodes": n_dend, "n_bif": n_bif,
             "n_tips": n_tips, "mean_seg_len": mean_seg_len,
             "max_radial": max_radial, **sholl,
             "bif_imbalance": float(np.mean(imbal)) if imbal else np.nan,
             "bif_angle_mean": float(np.mean(angles)) if angles else np.nan,
             "branch_order_entropy": entropy,
             "z_extent": z_extent, "z_offset": z_offset}
    qc.update({"flag": "", "n_dangling": n_dangling,
               "has_soma": bool((t == TYPE_SOMA).any())})
    return feats, qc


def main():
    man = pd.read_csv(MANIFEST)
    rows, qcs = [], []
    for r in man.itertuples():
        try:
            feats, qc = extract_features(r.dend_path)
            qc["ok"] = True
        except Exception as e:                       # 读不了的文件点名，不悄悄跳过
            feats = {f: np.nan for f in FEATURE_NAMES}
            qc = {"n_dend": np.nan, "radius_unique": "", "flag": f"读取失败:{e}",
                  "n_dangling": np.nan, "has_soma": False, "ok": False}
        rows.append({"sample_id": r.sample_id, "neuron_id": r.neuron_id, **feats})
        qcs.append({"sample_id": r.sample_id, "neuron_id": r.neuron_id, **qc})
    feat_df = pd.DataFrame(rows)
    qc_df = pd.DataFrame(qcs)
    feat_df.to_csv(OUT_DIR / "dendrite_features.csv", index=False)

    ok = qc_df[qc_df["ok"]]
    bad = qc_df[~qc_df["ok"]]
    all_r = sorted({v for s in ok["radius_unique"] for v in s.split(",") if v},
                   key=float)
    lines = [
        "P3 特征提取 QC（dendrite_features.py 生成）",
        "",
        f"提取成功 {len(ok)}/{len(qc_df)}，失败 {len(bad)}（失败样本在 dendrite_features.csv 里为全 NaN）",
        f"树突节点数：中位 {ok['n_dend'].median():.0f}，最小 {ok['n_dend'].min():.0f}，"
        f"最大 {ok['n_dend'].max():.0f}",
        f"树突过小（<{MIN_DEND_NODES}节点）被标 NaN：{(ok['flag'] != '').sum()} 个",
        f"断链节点总数（预期0）：{ok['n_dangling'].sum():.0f}",
        f"缺胞体（用第一个根当参考点）：{(ok['has_soma'] == False).sum()} 个",
        "",
        f"风险1 验证｜半径列唯一值全集：{all_r}",
        "  若只有 '1' → 占位确认，半径特征整族作废正确；出现其他值 → 报 TA 复核",
        f"风险4 验证｜树突存在性：{len(ok)} 个神经元全部有树突数据",
    ]
    if len(bad):
        lines.append("失败清单：" +
                     "；".join(f"S{r.sample_id}N{r.neuron_id} {r.flag}"
                               for r in bad.itertuples()))
    (OUT_DIR / "dendrite_qc.txt").write_text("\n".join(lines), encoding="utf-8")
    print(f"已写入 outputs/: dendrite_features.csv, dendrite_qc.txt "
          f"（提取 {len(ok)}/{len(qc_df)}）")


if __name__ == "__main__":
    main()
